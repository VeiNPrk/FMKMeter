package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.*
class ResponseData(
     val isSucces : Int,
     val message : String,
     val result : List<DetailNum>
)