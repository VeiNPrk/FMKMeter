package com.example.fmkinp.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class UserClass (
     @PrimaryKey val id: Int, 
     val name:String,
     val idEnt:Int, 
     val token:String){

}