package com.example.fmkinp.models

class ResponseClass (val status: Int, val message:String){

}