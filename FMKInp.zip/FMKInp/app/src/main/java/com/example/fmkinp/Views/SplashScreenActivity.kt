package com.example.fmkinp.Views

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.example.fmkinp.App
import com.example.fmkinp.BR
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.SplashScreenViewModel
import com.example.fmkinp.databinding.ActivitySplashScreenBinding
import com.example.fmkinp.models.Event
import com.example.fmkinp.utils.NetworkUtils
import com.example.fmkinp.utils.SharedPreferencesUtils
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import com.treebo.internetavailabilitychecker.InternetAvailabilityChecker
import com.treebo.internetavailabilitychecker.InternetConnectivityListener

class SplashScreenActivity : AppCompatActivity(), InternetConnectivityListener {

    override fun onInternetConnectivityChanged(isConnected: Boolean) {
        if(isConnected)
            getFiribaseToken()
    }

    private val TAG = "SplashScreenActivity"
    private var repository = App.instance.getRepository()
    lateinit var viewModel: SplashScreenViewModel
    lateinit var binding : ActivitySplashScreenBinding
    lateinit var mInternetAvailabilityChecker:InternetAvailabilityChecker
    var token:String=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_splash_screen)
        binding.lifecycleOwner=this
        viewModel = ViewModelProviders.of(this)[SplashScreenViewModel::class.java]
        repository = App.instance.getRepository()!!
        viewModel.setLifecycle(this)
        InternetAvailabilityChecker.init(this)
        mInternetAvailabilityChecker = InternetAvailabilityChecker.getInstance()
        mInternetAvailabilityChecker.addInternetConnectivityListener(this)
        /*val prefs = getSharedPreferences("TOKEN_PREF", MODE_PRIVATE)
        token = prefs.getString("token", "")*/
        token = SharedPreferencesUtils.getString(this, SharedPreferencesUtils.NAME_PREF_TOKEN)

        Log.e(TAG, token)

        getFiribaseToken()
                
        viewModel.eventLiveData.observe(this, Observer { event ->
            when (event.event) {
                Event.ACTION -> {
                    if(event.msg.equals(viewModel.ACTION_GO_TO_REGISTRATION))
                        goToRegistration()
                    if(event.msg.equals(viewModel.ACTION_GO_TO_WORK))
                        goToWork()
                }
                Event.ERROR -> {
                    if(event.msg.equals(NetworkUtils.ERROR_NO_CONNECTION)) {
                        binding.setVariable(BR.viewModel, viewModel)
                        binding.executePendingBindings()
                    }
                    //goToRegistration()
                }
                else -> {
                    print("")
                }
            }
        })
    }

    private fun getFiribaseToken(){
       // val editor = getSharedPreferences("TOKEN_PREF", MODE_PRIVATE).edit()
        if (TextUtils.isEmpty(token)) {
            FirebaseInstanceId.getInstance().instanceId.addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "getInstanceId failed", task.exception)
                    viewModel.checkConnection()
                    return@OnCompleteListener
                }
                token = task.result?.token!!

                if (token!=null){
                    SharedPreferencesUtils.setString(this, SharedPreferencesUtils.NAME_PREF_TOKEN, token)
                    /*editor.putString("token", token)
                    editor.apply()*/
                }
                viewModel.getMyUser(token!!/* , editor*/)
            })
        }
        else
            viewModel.getMyUser(token!!/*, editor*/)
    }

    private fun goToRegistration(){
        val intent = Intent(this, RegistrationActivity::class.java)
        startActivity(intent)
    }

    private fun goToWork(){
        val intent = Intent(this, DetailChooseActivity::class.java)
        startActivity(intent)
    }
}
