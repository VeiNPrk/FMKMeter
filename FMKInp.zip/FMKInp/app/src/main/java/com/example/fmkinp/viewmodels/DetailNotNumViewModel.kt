package com.example.fmkinp.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.fmkinp.App
import com.example.fmkinp.Repository
import com.example.fmkinp.models.DetailNum

class DetailNotNumViewModel : AndroidViewModel {

    constructor(application: Application) : super(application)
    private var repository : Repository? = null

    init{
        repository = App.instance.getRepository()!!

    }
    override fun onCleared() {
        super.onCleared()
        repository = null
    }

    fun getControlDetails(type:Int, idCreateUser:Int) : LiveData<List<DetailNum>> {
        return repository!!.getControlDetails(type,idCreateUser)
    }

    fun getRepository() = repository
}