package com.example.fmkinp

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.fmkinp.databinding.RvChooseDetailMaketBinding
import com.example.fmkinp.models.TypeDetail


class DetailChooseRecyclerAdapter(_context: Context, val detailControlClickListener: DetailControlClickListener/*, data: ArrayList<DetailControl>*/) : RecyclerView.Adapter<DetailChooseRecyclerAdapter.DetailControlViewHolder>(){

    lateinit var context:Context;
    //private lateinit var detailControlClickListener : DetailControlClickListener;
    var data:List<TypeDetail> = ArrayList<TypeDetail>()
    interface DetailControlClickListener {
        fun onClick(idDetail : Int)
        //void onDeleteClick(PictureClass picture);
    }

    class DetailControlViewHolder(var binding: RvChooseDetailMaketBinding) :
        RecyclerView.ViewHolder(binding.getRoot()) {

        fun bind(detailControl: TypeDetail) {
            binding.setVariable(BR.detail, detailControl)
            //binding.detail=detailControl!!
            binding.executePendingBindings()
        }
    }

    fun setDetailsData(details: List<TypeDetail>){
        data=details
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DetailControlViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        //val bind = DataBindingUtil.in
        val binding: RvChooseDetailMaketBinding = DataBindingUtil.inflate(inflater, R.layout.rv_choose_detail_maket, parent, false)
        val viewHolder = DetailControlViewHolder(binding)
        return viewHolder
    }

    override fun onBindViewHolder(holder : DetailControlViewHolder, i : Int ) {
         //val detail = data.get(i);
        holder.bind(data.get(i))
        holder.binding.root.setOnClickListener {
            detailControlClickListener.onClick(data.get(i).id)
        }
    }

    override fun getItemCount() = data.size


}

