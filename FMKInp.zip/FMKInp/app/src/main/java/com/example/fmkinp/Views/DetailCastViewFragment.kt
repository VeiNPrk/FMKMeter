package com.example.fmkinp.Views

import android.os.Bundle
import android.util.TypedValue
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import android.widget.LinearLayout
import android.widget.RadioButton
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.example.fmkinp.BR
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.DetailCastViewModel
import com.example.fmkinp.databinding.FragmentDetailCastViewBinding
import android.view.*
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import com.example.fmkinp.models.DetailNum


class DetailCastViewFragment : Fragment() {
    private val TAG = "DetailCastViewFragment"
    lateinit var binding : FragmentDetailCastViewBinding
    lateinit var viewModel: DetailCastViewModel
    var detailId=0
    var typeDetail=0
    var isTablet:Boolean = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState:Bundle?):View {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_detail_cast_view, container, false);
        binding.lifecycleOwner=this
        activity?.intent?.extras?.let {
            detailId=it.getInt("key_id_detail",0)
            typeDetail=it.getInt("key_type_detail",0)
        }
        isTablet = context!!.resources.getBoolean(R.bool.isTablet)
        detailId = arguments?.let{it.getInt("key_id_detail",0)}!!
        if(detailId==0)
            detailId = arguments?.let{it.getInt("idDetail",0)}!!

        typeDetail = arguments?.let{it.getInt("key_type_detail",0)}!!
        if(typeDetail==0)
            typeDetail = arguments?.let{it.getInt("typeDetail",0)}!!

        viewModel = ViewModelProviders.of(this)[DetailCastViewModel::class.java]
        binding.setVariable(BR.viewModel, viewModel)
        return binding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        setHasOptionsMenu(true)
        super.onCreate(savedInstanceState)
    }

    override fun onActivityCreated(savedInstanceState:Bundle?) {
        super.onActivityCreated(savedInstanceState);

        /*viewModel.detail.observe(this, Observer { detail ->
            detail?.let {
                binding.setVariable(BR.detail, it)
                binding.executePendingBindings()
                observeNsiData(it)
            }
        })*/

        viewModel.getDetailLiveData(detailId, this).observe(this, Observer { detail ->
            detail?.let {
                binding.setVariable(BR.detail, it)
                binding.executePendingBindings()
                viewModel.checkWhenFind(it.whenFind)
                viewModel.initVrkFaultStr()
                observeNsiData(it)
                //setHasOptionsMenu(viewModel.isEditableDetail())
            }
        })
        //binding.includeBrak.rgVisNk.isEnabled=false
    }

    private fun observeNsiData(detail: DetailNum?){
        viewModel.getControlResults(typeDetail).observe(this, Observer { results ->
            val result = results.find { it.id==detail?.resultControl }
            viewModel.checkResultControl(result)

        })
        viewModel.getFactorysCreate(typeDetail).observe(this, Observer { factorys ->
            detail?.let{
                val factory = factorys.find { it.id==detail.idFactory }
                binding.tvFactory.text=factory?.shotName
            }
        })
        viewModel.getDefectTypes(typeDetail).observe(this, Observer { defTypes->
            detail?.let{
                val defType = defTypes.find { it.id==detail.typeDef && it.brakRemont==0 }
                binding.includeBrak.tvDefType.text=defType?.name
                binding.includeBrak.tvDefTypeNk.text=defType?.name
                val defTypeRemont = defTypes.find { it.id==detail.typeDef && it.brakRemont==1 }
                binding.includeRepair.tvDefType.text=defTypeRemont?.name
            }
        })
        viewModel.getDefectZones(typeDetail).observe(this, Observer { defZones->
            detail?.let{
                val defZone = defZones.find { it.id==detail.zoneDef}
                binding.includeBrak.tvZone.text=defZone?.name
                binding.includeBrak.tvZoneNk.text=defZone?.name
                binding.includeRepair.tvZone.text=defZone?.name
            }
        })
        viewModel.getSteels().observe(this, Observer { steels->
            detail?.let{
                val steel = steels.find { it.name==detail.steel}
                binding.includeBrak.tvSteelType.text=steel?.name
            }
        })
        viewModel.getMethodNkTypes(typeDetail).observe(this, Observer {methodTypes->
            detail?.let{
                val method = methodTypes.find { it.name==detail.methodType}
                binding.includeBrak.tvMetodType.text=method?.name
            }
        })
        viewModel.getDefectDetectorTypes().observe(this, Observer { detectors->
            detail?.let{
                val detector = detectors.find { it.name==detail.defectDetector}
                binding.includeBrak.tvDefektoskopType.text=detector?.name
            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.action_menu_view, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_edit -> {
            when {
                isTablet -> {
                    val navHostFragment = parentFragment?.fragmentManager?.findFragmentById(R.id.detail_nav_container) as NavHostFragment
                    val bundleToTransfer = Bundle()
                    bundleToTransfer.putInt("key_id_detail", detailId)
                    bundleToTransfer.putInt("key_type_detail", typeDetail)
                    navHostFragment.navController.navigate(R.id.detailCastEditFragment, bundleToTransfer)
                }
                else -> {
                    val action = DetailCastViewFragmentDirections.actionDetailCastViewFragmentToDetailCastEditFragment(detailId, typeDetail)
                    view?.let { Navigation.findNavController(it).navigate(action) }!!
                }
            }
            true
        }
        else -> {
            super.onOptionsItemSelected(item)
        }
    }
}
