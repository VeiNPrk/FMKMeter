package com.example.fmkinp.utils

import android.view.View
import android.widget.AdapterView
import android.widget.Spinner
import androidx.databinding.BindingAdapter
import androidx.databinding.InverseBindingAdapter
import androidx.databinding.InverseBindingListener
import androidx.databinding.InverseMethod
import com.example.fmkinp.models.DefectType
import java.util.*
import kotlin.collections.List as List1

object Converter {
    @InverseMethod("convertToInt")
    @JvmStatic fun convertToBoolean(checked: Int): Boolean {
        return checked == 1
    }

    @JvmStatic fun convertToInt(checked: Boolean): Int {
        return if (checked) 1 else 0
    }
/*
    @BindingAdapter(value = ["projects", "selectedProject", "selectedProjectAttrChanged"], requireAll = false)
    fun setProjects (spinner: Spinner, projects: List<DefectType> ?, selectedProject: DefectType, listenener: InverseBindingListener) {
        if (projects == null) return
        //spinner.adapter = NameAdapter (spinner.context, android.R.layout.simple_spinner_dropdown_item, projects)
        setCurrentSelection (spinner, selectedProject)
        setSpinnerListener (spinner, listenener)
    }
    @InverseBindingAdapter(attribute = "selectedProject")
    fun getSelectedProject (spinner: Spinner): DefectType {
        return spinner.selectedItem as DefectType
    }

    private fun setSpinnerListener(spinner: Spinner, listener: InverseBindingListener) {
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) = listener.onChange()
            override fun onNothingSelected(adapterView: AdapterView<*>) = listener.onChange()
        }
    }

    private fun setCurrentSelection(spinner: Spinner, selectedItem: DefectType): Boolean {
        for (index in 0 until spinner.adapter.count) {
            if (spinner.getItemAtPosition(index) == selectedItem.name) {
                spinner.setSelection(index)
                return true
            }
        }
        return false
    }*/
}