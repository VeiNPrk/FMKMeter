package com.example.fmkinp.models

class EventClass(val event: Event, val msg: String) 