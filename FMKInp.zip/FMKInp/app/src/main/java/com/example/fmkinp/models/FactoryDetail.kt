package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
@Entity
class FactoryDetail(
     @SerializedName("id_zavods")
     @PrimaryKey val id:Int,
     @SerializedName("full_name") 
     val fullName:String,
     @SerializedName("shot_name") 
     val shotName:String,
     @SerializedName("id_part") 
     val typeDetail:Int,
     @SerializedName("code") 
     val code:String,
     @SerializedName("gov") 
     val gov:String,
     @SerializedName("description") 
     val description:String?,
     @SerializedName("order_field") 
     val orderField:Int
)
{
     override fun toString(): String = shotName
}