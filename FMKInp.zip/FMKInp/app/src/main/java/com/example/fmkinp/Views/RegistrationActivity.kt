package com.example.fmkinp.Views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProviders
import com.example.fmkinp.Contractors.MainContractor
//import com.example.fmkinp.Presenters.MainPresenter
import com.example.fmkinp.viewmodels.RegistrationViewModel
import com.example.fmkinp.databinding.ActivityMainBinding
import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import com.example.fmkinp.R
import com.example.fmkinp.databinding.ActivityRegistrationBinding
import com.example.fmkinp.models.Event
import com.example.fmkinp.utils.SharedPreferencesUtils
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId


class RegistrationActivity : AppCompatActivity() {
    lateinit var binding: ActivityRegistrationBinding
    var token: String = ""

    //var presenter : MainContractor.Presenter<MainContractor.View>? = null
    private val TAG = "RegistrationActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_registration)
        val viewModel = ViewModelProviders.of(this)[RegistrationViewModel::class.java]
        //viewModel.setLifecycle(this)
        binding.setViewModel(viewModel)
        /*val prefs = getSharedPreferences("TOKEN_PREF", MODE_PRIVATE)
        token = prefs.getString("token", "")*/
        token = SharedPreferencesUtils.getString(this, SharedPreferencesUtils.NAME_PREF_TOKEN)

        //val editor = prefs.edit()
        if (TextUtils.isEmpty(token)) {
            FirebaseInstanceId.getInstance()
                .instanceId.addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "getInstanceId failed", task.exception)
                    return@OnCompleteListener
                }
                token = task.result?.token!!

                if (token != null) {
                    SharedPreferencesUtils.setString(this, SharedPreferencesUtils.NAME_PREF_TOKEN, token)
                    /*editor.putString("token", token)
                    editor.apply()*/
                }
                //viewModel.getMyUser(token!!)
            })
        }
        viewModel.getMyUser(token).observe(this, Observer {
            it?.let{
                SharedPreferencesUtils.setUser(this, it)
                /*editor.putInt("my_user_id", it.id)
                editor.apply()
                editor.putInt("my_user_ent", it.idEnt)
                editor.apply()*/
                goToInp()
            }
        })

        binding.btnRegistration.setOnClickListener {
            //val phone = binding.tvPhoneNumber.text.toString().replace("[^\\d]".toRegex(), "")
            showErrorForm(false, "")
            viewModel?.authorization(binding.etLogin.text.toString(), binding.etPassword.text.toString(), token)
            // [END retrieve_current_token]
        }
        binding.btnSendCode.setOnClickListener {
            showErrorForm(false, "")
            viewModel?.sendAuthCode(binding.tvAuthorizeCode.text.toString(),token)
        }

        //var lastChar = ""
 /*       binding.tvPhoneNumber.addTextChangedListener(object : TextWatcher {
            //we need to know if the user is erasing or inputing some new character
            private var backspacingFlag = false
            //we need to block the :afterTextChanges method to be called again after we just replaced the EditText text
            private var editedFlag = false
            //we need to mark the cursor position and restore it after the edition
            private var cursorComplement = 0

            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                //we store the cursor local relative to the end of the string in the EditText before the edition
                cursorComplement = s.length - binding.tvPhoneNumber.selectionStart
                //we check if the user ir inputing or erasing a character
                backspacingFlag = if (count > after) true else false
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                // nothing to do here =D
            }

            override fun afterTextChanged(s: Editable?) {
                var string: String = s.toString()
                //what matters are the phone digits beneath the mask, so we always work with a raw string with only digits
                val phone = string.replace("[^\\d]".toRegex(), "")
                //if the text was just edited, :afterTextChanged is called another time... so we need to verify the flag of edition
                //if the flag is false, this is a original user-typed entry. so we go on and do some magic
                if (!editedFlag) {

                    //we start verifying the worst case, many characters mask need to be added
                    //example: 999999999 <- 6+ digits already typed
                    // masked: (999) 999-999
                    if (phone.length >= 6 && !backspacingFlag) {
                        //we will edit. next call on this textWatcher will be ignored
                        editedFlag = true
                        //here is the core. we substring the raw digits and add the mask as convenient
                        val ans = "(" + phone.substring(0, 3) + ") " + phone.substring(
                            3,
                            6
                        ) + "-" + phone.substring(6)
                        binding.tvPhoneNumber.setText(ans)
                        //we deliver the cursor to its original position relative to the end of the string
                        binding.tvPhoneNumber.setSelection(binding.tvPhoneNumber.text.length - cursorComplement)

                        //we end at the most simple case, when just one character mask is needed
                        //example: 99999 <- 3+ digits already typed
                        // masked: (999) 99
                    } else if (phone.length >= 3 && !backspacingFlag) {
                        editedFlag = true
                        val ans = "(" + phone.substring(0, 3) + ") " + phone.substring(3)
                        binding.tvPhoneNumber.setText(ans)
                        binding.tvPhoneNumber.setSelection(binding.tvPhoneNumber.getText().length - cursorComplement)
                    }
                    // We just edited the field, ignoring this cicle of the watcher and getting ready for the next
                } else {
                    editedFlag = false
                }
            }

        })
*/
        viewModel.eventLiveData.observe(this, Observer { action->
            when(action.event){
                Event.ACTION -> {
                    /*if(action.msg.equals(RegistrationViewModel.ACTION_GO_TO_WORK))
                        goToInp()*/
                }
                else ->{
                    showErrorForm(true, action.msg)
                }
            }
        })
    }

    public override fun onStop() {
        super.onStop()
    }

    fun goToInpTest() {

    }

    fun showErrorForm(show: Boolean, msg:String) {
        binding.layoutErrorForm.visibility = if (show) View.VISIBLE else View.GONE
        binding.tvError.setText(msg)
    }

    /*fun showSendCodeForm(show: Boolean) {
        binding.layoutSendCode.visibility = if (show) View.VISIBLE else View.GONE
    }*/

    fun goToInp() {
        Log.d(TAG, "goToInp")
    }

    /*fun showError(show: Boolean, message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }*/

}
