//package com.example.fmkinp.utils;

import androidx.databinding.InverseMethod;

/*public class Converter {
        public static boolean convertToBoolean(int checked){
            if(checked==1) return true; else return false;
        }

        @InverseMethod("convertToBoolean")
        public static int convertToInt(boolean checked){
            if(checked) return 1; else return 0;
        }
}*/
