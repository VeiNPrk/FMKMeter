package com.example.fmkinp

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.work.ListenableWorker
import com.example.fmkinp.Room.DaoInp
import com.example.fmkinp.models.*
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.lang.Exception
import kotlin.collections.ArrayList
import androidx.work.Worker

class Repository() {

    private var _myUser = MutableLiveData<UserClass>()
    lateinit var myUser: LiveData<UserClass>
    private var inpDao: DaoInp
    private val networkState = MutableLiveData<NetworkState>()
    private val networkStateAuthorization = MutableLiveData<NetworkState>()
    private val networkStateSendCode = MutableLiveData<NetworkState>()

    val TAG = "Repository"
    //var detailsControlList = ArrayList<TypeDetail>()
    var detailsList = ArrayList<DetailNum>()

    init {
        val db = App.instance.getDatabase()
        inpDao = db!!.inpDao()
        //initTestData()
    }

    fun selectMyUser(token: String) : LiveData<UserClass> = inpDao.getMyUser(token)

    fun getChooseDetails() = inpDao.getTypesDetail()// detailsControlList

    fun getControlResults(typeDetail:Int) = inpDao.getControlResults(typeDetail)

    fun getFactorysDetail(typeDetail:Int) = inpDao.getFactorysDetail(typeDetail)

    fun getEntSpecialsts() = inpDao.getEntSpecialists()

    fun getControlDetails(type:Int, idCreateUser:Int) = inpDao.getControlDetails(type, idCreateUser)

    fun getDefectTypes(typeDetail :Int) = inpDao.getDefectTypes(typeDetail)

    fun getDefectZones(typeDetail :Int) = inpDao.getDefectZones(typeDetail)

    fun getSteels() = inpDao.getSteels()

    fun getMethodNkTypes(typeDetail :Int) = inpDao.getMethodNkTypes(typeDetail)

    fun getDefectDetectorTypes() = inpDao.getDefectDetectorTypes()

    fun getDetail(idDetail:Int) = inpDao.getControlDetail(idDetail)

    suspend fun syncronizeData(userId:Int, userEnt:Int):ListenableWorker.Result {
        Log.d("coroutine", "syncronizeData Start")
        networkState.postValue(NetworkState.LOADING)
        val syncDetails = inpDao.getNotLoadedControlDetails()
        var jsonData:String = Gson().toJson(syncDetails)
        val response = App.instance.getApi().synchronizeCastData(userId, userEnt, jsonData)
        //val response = App.instance.getApi().getControlData(userId, userEnt)
        Log.d("coroutine", "syncronizeData1")
        try {
            if (response?.isSuccessful!! && response.code() == 200) {
                    val responseData: ResponseData? = response.body()
                if (responseData!!.isSucces==1) {
                        //inpDao.insertCastDetails(responseData.result)
                        inpDao!!.synchronizeCastDetails(syncDetails, responseData.result)
                        Log.d("coroutine", "syncronizeData2")
                        networkState.postValue(NetworkState(Status.SUCCESS, ""))
                        return ListenableWorker.Result.success()
                } else {
                        networkState.postValue(NetworkState(Status.FAILED, responseData.message))
                        return ListenableWorker.Result.retry()
                }
            } else {
                    Log.e(TAG, response.message())
                    networkState.postValue(NetworkState(Status.FAILED, response.message()));
                    return ListenableWorker.Result.retry()
            }
        } catch (e: Exception) {
                val errorMessage = e.message
                Log.d(TAG, errorMessage)
                networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
                return ListenableWorker.Result.failure()
        } catch (e: Throwable) {
                val errorMessage = e.message
                Log.d(TAG, errorMessage)
                networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
                return ListenableWorker.Result.failure()
        }
    }

    suspend fun syncronizeNsiData(idEnt:Int) {
        Log.d("coroutine", "initData Start")
        networkState.postValue(NetworkState.LOADING)
        val response = App.instance.getApi().getInitData(idEnt)
        Log.d("coroutine", "repository1")
            try {
                if (response?.isSuccessful!! && response.code() == 200) {
                    val responseInitData: ResponseInitData? = /*Log.d(TAG,*/response.body()/*.toString())*/
                    if (responseInitData!!.isSucces==1) {

                        inpDao!!.insertInit(
                            responseInitData.types, 
                            responseInitData.factorys,
                            responseInitData.results,
                            responseInitData.specialists,
                            responseInitData.typesDeffect,
                            responseInitData.zones,
                            responseInitData.steel,
                            responseInitData.typesMethodNk,
                            responseInitData.typesDefectDetector)

                        Log.d("coroutine", "repository2")
                        networkState.postValue(NetworkState(Status.SUCCESS, ""))
                    } else {
                        networkState.postValue(NetworkState(Status.FAILED, responseInitData.message))
                    }
                } else {
                    Log.e(TAG, response.message())
                    networkState.postValue(NetworkState(Status.FAILED, response.message()))
                }
            } catch (e: Exception) {
                val errorMessage = e.message
                Log.d(TAG, errorMessage)
                networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
            } catch (e: Throwable) {
                val errorMessage = e.message
                Log.d(TAG, errorMessage)
                networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
            }
        //}


        /*App.instance.getApi().getInitData(idEnt).enqueue(object : Callback<ResponseInitData> {
                override fun onResponse(call: Call<ResponseInitData>, response: Response<ResponseInitData>) {
                    if (response?.isSuccessful()!! && response.code() == 200) {
                        val strJson = response.body().toString()
                        val responseInitData: ResponseInitData = response.body()
                        if (responseInitData.isSucces) {
                            //inpDao!!.insertInit(responseInitData.types, responseInitData.factorys)
                            //networkState.postValue(NetworkState.LOADING, "���� �������");
                            //inpDao!!.insertInitFactoryDetail(responseInitData.factorys)
                            networkState.postValue(NetworkState(Status.SUCCESS, ""));
                        } else {
                            networkState.postValue(NetworkState(Status.FAILED, responseInitData.message))
                        }
                    } else {
                        Log.e(TAG, response.message())
                        networkState.postValue(NetworkState(Status.FAILED, response.message()));
                    }
                }

                override fun onFailure(call: Call<ResponseInitData>, t: Throwable) {
                    val errorMessage = t.message
                    Log.d(TAG, errorMessage)
                    networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
                }
        })*/
        
        
        /*App.instance.getApi().getInitData(idEnt).enqueue(object : Callback<String> {
            override fun onResponse(call: Call<String>, response: Response<String>) {
                Log.e("TAG", "response 33: "+ Gson().toJson(response.body()) );
            }

            override fun onFailure(call: Call<ResponseInitData>, t:Throwable ) {
                Log.e("TAG", "onFailure: "+t.toString() );
                // Log error here since request failed
            }
        });*/
    }

    suspend fun getControlDetails() = inpDao.getControlDetails()

    suspend fun getMaxId() =inpDao.getMaxIdDetails()

    suspend fun insertCastDetail(detail:DetailNum) {
        inpDao.insertControlDetail(detail)
    }

    suspend fun updateCastDetail(detail:DetailNum) {
        inpDao.updateControlDetail(detail)
    }

    suspend fun insertCastDetailToRemote(detail:DetailNum) {
        var jsonData:String = Gson().toJson(detail)
        /*Log.d("coroutine", "insertCastDetail Start")
        inpDao!!.insertControlDetail(detail)*/
        networkState.postValue(NetworkState.LOADING)
        val response = App.instance.getApi().insertDetail(jsonData)
        Log.d("coroutine", "insertCastDetail 1")
        try {
            if (response?.isSuccessful!! && response.code() == 200) {
                val responseData: ResponseData? = response.body()
                if (responseData!!.isSucces==1) {
                    for (newDetail in responseData.result){
                        //val t1 = inpDao!!.getControlDetailsByid(detail.id)
                        inpDao.updateIdDetail(detail, newDetail)
                    }
                    Log.d("coroutine", "insertCastDetail 2")
                    networkState.postValue(NetworkState(Status.SUCCESS, ""))
                } else {
                    networkState.postValue(NetworkState(Status.FAILED, responseData.message))
                }
            } else {
                Log.e(TAG, response.message())
                networkState.postValue(NetworkState(Status.FAILED, response.message()))
            }
        } catch (e: Exception) {
            val errorMessage = e.message
            Log.d(TAG, errorMessage)
            networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
        } catch (e: Throwable) {
            val errorMessage = e.message
            Log.d(TAG, errorMessage)
            networkState.postValue(NetworkState(Status.FAILED, errorMessage!!))
        }
    }

    fun authorization(login: String, pasw: String, token: String?) {
        Log.d(TAG, "authorization " + login)
        //pokemonList.clear();
        networkStateAuthorization.postValue(NetworkState.LOADING)

        token?.let {
            App.instance.getApi().authorization(login, pasw, token).enqueue(object : Callback<ResponseClass> {
                override fun onResponse(call: Call<ResponseClass>, response: Response<ResponseClass>) {
                        if (response?.isSuccessful()!! && response.code() == 200) {
                            val responseClass: ResponseClass? = response.body()
                            if (responseClass?.status == 1) {
                                networkStateAuthorization.postValue(NetworkState.LOADED)
                            } else {
                                networkStateAuthorization.postValue(NetworkState(Status.FAILED, responseClass!!.message))
                            }
                            /*try{
                                user?.let{
                                    insertUser(user)
                                }
                            }
                            catch (ex:Exception){
                                networkState.postValue(NetworkState(Status.FAILED, ex.message))
                                //Log.d(TAG, "params.size="+params[0].size()+" ex="+ex.message);
                            }*/
                        } else {
                            Log.e(TAG, response.message())
                            networkStateAuthorization.postValue(NetworkState(Status.FAILED, response.message()))
                        }
                    }

                    override fun onFailure(call: Call<ResponseClass>, t: Throwable) {
                        val errorMessage = t.message
                        Log.d(TAG, errorMessage)
                        networkStateAuthorization.postValue(NetworkState(Status.FAILED, errorMessage!!))
                    }
                })

            //Log.d(TAG,ar.toString())
            /*.enqueue(object : Callback<PokemonClass> {
                override fun onResponse(
                    call: Call<PokemonClass>,
                    response: Response<PokemonClass>
                ) {
                    val pokemon = response.body()
                    pokemonList.add(PokemonUtils.convertToPokemon(pokemon))
                    if (pokemonResp.getResults().size() === pokemonList.size) {
                        insert(pokemonList)
                    }
                }

                override fun onFailure(call: Call<PokemonClass>, t: Throwable) {
                    pokemonList.add(null)
                    if (pokemonResp.getResults().size() === pokemonList.size)
                        insert(pokemonList)
                }
            })*/
        }
    }

    suspend fun sendRegistrationCode(code: String, token: String?) {
        Log.d(TAG, "sendRegistrationCode " + code)
        //pokemonList.clear();
        networkStateSendCode.postValue(NetworkState.LOADING)

        token?.let {
            val response = App.instance.getApi().sendAuthCode(code, token)
            //withContext(Dispatchers.Main) {
            try {
                if (response?.isSuccessful!! && response.code() == 200) {
                    val userClass: UserClass? = response.body()
                    if (userClass?.id!! > 0) {
                        inpDao.insertUser(userClass!!)
                        syncronizeNsiData(userClass.idEnt)
                        networkStateSendCode.postValue(NetworkState.LOADED)
                    } else {
                        networkStateSendCode.postValue(NetworkState(Status.FAILED, userClass.name))
                    }
                } else {
                    Log.e(TAG, response.message())
                    networkStateSendCode.postValue(NetworkState(Status.FAILED, response.message()))
                }
            } catch (e: Exception) {
                val errorMessage = e.message
                Log.d(TAG, errorMessage)
                networkStateSendCode.postValue(NetworkState(Status.FAILED, errorMessage!!))
            } catch (e: Throwable) {
                val errorMessage = e.message
                Log.d(TAG, errorMessage)
                networkStateSendCode.postValue(NetworkState(Status.FAILED, errorMessage!!))
            }
        }
    }

    private fun insertUser(user: UserClass) {
        //insertUserAsyncTask(inpDao).execute(user);
    }

    /*private class insertUserAsyncTask(dao : DaoInp) : AsyncTask<UserClass, Void, Void>() {

         private lateinit var mAsyncTaskDao : DaoInp

         init {
             mAsyncTaskDao = dao;
         }

         override fun doInBackground(vararg params : UserClass): Void? {
             try {
                 //params[0].removeAll(Collections.singleton(null));
                 mAsyncTaskDao.insert(params[0])
                 networkState.postValue(NetworkState.LOADED);
                 //int max = mAsyncTaskDao.getMaxPokemon();
                 //App.setPokemonLastOffset(max);
             }
             catch (ex : java.lang.Exception){
                 networkState.postValue(NetworkState(com.example.siberspokemon.Models.Status.FAILED, ex.getMessage()));
                 Log.d("insertUserAsyncTask", "params.size="+params[0].size()+" ex="+ex.getMessage());
             }
             return null;
         }
    }*/

    fun updateToken(id: Int, token: String?) {

    }

    fun registrationUser() {

    }

    fun getMyUserLiveData() = myUser

    fun getNetworkState() = networkState
    fun getNetworkStateAuthorization() = networkStateAuthorization
    fun getNetworkStateSendCode() = networkStateSendCode

}