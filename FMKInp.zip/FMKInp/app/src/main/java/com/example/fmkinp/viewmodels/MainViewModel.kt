package com.example.fmkinp.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.fmkinp.App
import com.example.fmkinp.Contractors.MainContractor
import com.example.fmkinp.Repository

class MainViewModel : AndroidViewModel {

    constructor(application: Application) : super(application)
    private var presenter : MainContractor.Presenter<MainContractor.View>? = null
    private var repository : Repository? = null

    init{
        repository = App.instance.getRepository()!!
    }
    override fun onCleared() {
        super.onCleared()
        presenter?.onPresenterDestroy()
        presenter = null
        repository = null
    }

    internal fun setPresenter(presenter: MainContractor.Presenter<MainContractor.View>) {
        if (this.presenter == null) {
            this.presenter = presenter
            //this.presenter?.setContext(getApplication<Application>())
            //this.presenter.setRepository(repository);
        }
    }

    fun getPresenter() = presenter

    fun getRepository() = repository
}