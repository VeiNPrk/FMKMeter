package com.example.fmkinp.Views

import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.DetailNotNumViewModel
import com.example.fmkinp.databinding.FragmentDetailNotnumViewBinding


class DetailNotNumViewFragment : Fragment() {
    private val TAG = "DetailNotNumViewFragment"
    lateinit var binding : FragmentDetailNotnumViewBinding
    lateinit var viewModel: DetailNotNumViewModel
    var view =null

    var detailType=0

    /*companion object{
        private val KEY_TYPE_DETAIL = "key_type_detail"

        fun openActivity(context: Context, typeDetail:Int){
            val intent = Intent(context, ControlActivity.javaClass);
            intent.putExtra(KEY_TYPE_DETAIL, typeDetail);
            if (!(context is Activity))
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }*/

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                               savedInstanceState:Bundle?):View {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_detail_notnum_view, container, false);
        //view = ((ViewDataBinding) binding).getRoot();
        binding.lifecycleOwner=this
        return binding.root
    }

    override fun onActivityCreated( savedInstanceState:Bundle?) {
        super.onActivityCreated(savedInstanceState);
        viewModel = ViewModelProviders.of(this)[DetailNotNumViewModel::class.java]
       /* viewModel.getControlDetails(detailType).observe(this, Observer { details ->
            details?.let { mAdapter.setDetailsData(it) }
        })*/
         /*int idPokemon = DetailFragmentArgs.fromBundle(getArguments()).getIdPokemon();
        savedInstanceState?.let{
            detailType=savedInstanceState.getInt(KEY_TYPE_DETAIL, 0)
        }*/
    }



    /*override fun onClick(idDetail: Int) {
        //ControlActivity.openActivity(idDetail)
        Toast.makeText(this, "idDetail= $idDetail", Toast.LENGTH_LONG).show()
    }*/

}
