package com.example.fmkinp.models

data class DetailControl(
    val id:Int,
    val name: String,
    val imgUrl: String
)