package com.example.fmkinp.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.example.fmkinp.App
import com.example.fmkinp.Repository
import com.example.fmkinp.models.ControlResult
import com.example.fmkinp.models.DetailNum

class ControlListViewModel : AndroidViewModel {

    constructor(application: Application) : super(application)
    private var repository : Repository? = null
    private var results:List<ControlResult> = ArrayList<ControlResult>()

    init{
        repository = App.instance.getRepository()!!

    }
    override fun onCleared() {
        super.onCleared()
        repository = null
    }

    fun initControlResults(lifecycleOwner: LifecycleOwner, typeDetail:Int){
        repository!!.getControlResults(typeDetail).observe(lifecycleOwner, Observer {
            results=it
        })
    }

    fun getControlDetails(type:Int, idCreateUser:Int) : LiveData<List<DetailNum>> {
        return repository!!.getControlDetails(type,idCreateUser)
    }

    fun addingResult(details: List<DetailNum>): List<DetailNum>{
        details.forEach {
            var idResult:Int = it.resultControl
            it.nameResult=results.find { it.id==idResult }?.name ?: ""
        }
        return details
    }

    fun getRepository() = repository
}