package com.example.fmkinp.Room

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.fmkinp.models.*

@Dao
/*interface*/abstract class DaoInp {

    // LiveData is a data holder class that can be observed within a given lifecycle.
    // Always holds/caches latest version of data. Notifies its active observers when the
    // data has changed. Since we are getting all the contents of the database,
    // we are notified whenever any of the database contents have changed.
    /*@get:Query("SELECT * from signal ORDER BY time ASC")
    fun allSignalls: LiveData<List<UserClass>>*/

    @Query("SELECT * FROM userclass WHERE token=:token")
    abstract fun getMyUser(token :String): LiveData<UserClass>

    @Query("SELECT * FROM typedetail where id in(6,7,11,12)")
    abstract fun getTypesDetail(): LiveData<List<TypeDetail>>

    @Query("SELECT * FROM factorydetail WHERE typeDetail=:type")
    abstract fun getFactorysDetail(type :Int): LiveData<List<FactoryDetail>>

    @Query("SELECT * FROM detailnum order by id desc")
    abstract suspend fun getControlDetails(): List<DetailNum>

    @Query("SELECT * FROM detailnum where id=:id order by id desc")
    abstract suspend fun getControlDetailsByid(id:Int): List<DetailNum>

    @Query("SELECT * FROM detailnum where isLoaded=0 order by id desc")
    abstract fun getNotLoadedControlDetails(): List<DetailNum>

    @Query("SELECT max(id) FROM detailnum")
    abstract suspend fun getMaxIdDetails(): Int

    @Query("SELECT * FROM detailnum WHERE type=:typeDetail AND idCreateUser=:idCreateUser order by id desc")
    abstract fun getControlDetails(typeDetail :Int, idCreateUser:Int): LiveData<List<DetailNum>>

    @Query("SELECT * FROM controlresult where typeDetail=:typeDetail order by orderBy")
    abstract fun getControlResults(typeDetail :Int): LiveData<List<ControlResult>>

    @Query("SELECT * FROM entspecialist order by lastName")
    abstract fun getEntSpecialists(): LiveData<List<EntSpecialist>>

    @Query("SELECT * FROM detailnum WHERE id=:idDetail")
    abstract fun getControlDetail(idDetail :Int): LiveData<DetailNum>

    @Query("SELECT * FROM defecttype where typeDetail=:typeDetail order by id")
    abstract fun getDefectTypes(typeDetail :Int): LiveData<List<DefectType>>

    @Query("SELECT * FROM defectzone where typeDetail=:typeDetail order by orderBy")
    abstract fun getDefectZones(typeDetail :Int): LiveData<List<DefectZone>>

    @Query("SELECT * FROM steel")
    abstract fun getSteels(): LiveData<List<Steel>>

    @Query("SELECT * FROM methodnktype where typeDetail=:typeDetail")
    abstract fun getMethodNkTypes(typeDetail :Int): LiveData<List<MethodNkType>>

    @Query("SELECT * FROM defectdetectortype order by id")
    abstract fun getDefectDetectorTypes(): LiveData<List<DefectDetectorType>>


    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertUser(users: UserClass)

    @Insert/*(onConflict = OnConflictStrategy.IGNORE)*/
    abstract suspend fun insertControlDetail(detail: DetailNum)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract fun insertCastDetails(details: List<DetailNum>)

    @Update
    abstract suspend fun updateControlDetail(detail: DetailNum)

    @Query("UPDATE detailnum SET id = :newId, isLoaded=1 WHERE numDetail = :num AND _dateControl = :dtControl")
    abstract suspend fun updateIdDetail(newId: Int, num: String?, dtControl: String): Int

    @Delete
    abstract suspend fun deleteControlDetail(detail: DetailNum)

    @Delete
    abstract suspend fun deleteCastDetails(details: List<DetailNum>)

    @Transaction
    open suspend fun insertInit(
        types: List<TypeDetail>,
        factorys: List<FactoryDetail>,
        results: List<ControlResult>,
        specialists: List<EntSpecialist>,
        defectType : List<DefectType>,
        defectZone : List<DefectZone>,
        steel : List<Steel>,
        methodNkType : List<MethodNkType>,
        defectDetectorType : List<DefectDetectorType>
    ) {
        insertInitTypeDetail(types)
        insertInitFactoryDetail(factorys)
        insertInitResult(results)
        insertInitSpecialist(specialists)
        insertInitDefectType(defectType)
        insertInitDefectZone(defectZone)
        insertInitSteel(steel)
        insertInitMethodNkType(methodNkType)
        insertInitDefectDetectorType(defectDetectorType)
    }

    @Transaction
    open suspend fun updateIdDetail(oldDetail: DetailNum, newDetail: DetailNum) {
        deleteControlDetail(oldDetail)
        insertControlDetail(newDetail)
    }

    @Transaction
    open suspend fun synchronizeCastDetails(oldDetails: List<DetailNum>, newDetails: List<DetailNum>) {
        deleteCastDetails(oldDetails)
        insertCastDetails(newDetails)
    }

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitTypeDetail(types: List<TypeDetail>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitFactoryDetail(factorys: List<FactoryDetail>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitResult(results: List<ControlResult>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitSpecialist(specialists: List<EntSpecialist>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitDefectType(defectType : List<DefectType>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitDefectZone(defectZone : List<DefectZone>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitSteel(steel : List<Steel>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitMethodNkType(methodNkType : List<MethodNkType>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertInitDefectDetectorType(defectDetectorType : List<DefectDetectorType>)
}