package com.example.fmkinp.utils

import java.text.SimpleDateFormat
import java.util.*

class DateUtils() {
    companion object {

        fun getLastNYears(nYears: Int): List<Int> {
            val c = Calendar.getInstance()
            val nowYear = c.get(Calendar.YEAR)
            val finishYear = nowYear - nYears
            val rangeYears = nowYear.downTo(finishYear)

            val years = rangeYears.toList()
            /*for(y in rangeYears){
                years.add(y.toString())
            }*/
            return years
        }

        fun getDateFromMills(milsec: Long) = Date(milsec)

        //fun getDateFromString(strDate: String) = SimpleDateFormat("dd.MM.yyyy").parse(strDate)

        fun getDateFromString(strDate: String): Date {
            //SimpleDateFormat("dd.MM.yyyy").parse(strDate)
            val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
            dateFormat.timeZone = TimeZone.getTimeZone("GMT")
            return dateFormat.parse(strDate)
        }

        fun getSimpleDateStr(date: Date) = SimpleDateFormat("dd.MM.yyyy").format(date)

        fun getSimpleDateTimeStr(date: Date) = SimpleDateFormat("dd.MM.yyyy HH:mm:ss").format(date)

        fun is24HourInterval(dateCreateMills:Long):Boolean{
            val nowTimeMills = Date().time
            val raznMills = nowTimeMills - dateCreateMills
            val hours = raznMills/(1000 * 60 * 60)
            return hours<24
        }

    }
}