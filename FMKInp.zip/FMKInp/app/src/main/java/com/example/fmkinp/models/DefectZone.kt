package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
@Entity
class DefectZone(
     @SerializedName("id_zon")
     @PrimaryKey val id:Int,
     @SerializedName("id_part") 
     val typeDetail:Int,
     @SerializedName("name_zone") 
     val name:String,
     @SerializedName("order_field") 
     val orderBy:Int
){
     override fun toString()=name
}