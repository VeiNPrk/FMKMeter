package com.example.fmkinp.viewmodels

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo
import androidx.core.content.ContextCompat.getSystemService
import androidx.lifecycle.*
import androidx.work.WorkInfo
import com.example.fmkinp.App
import com.example.fmkinp.NetworkState
import com.example.fmkinp.Repository
import com.example.fmkinp.models.Event
import com.example.fmkinp.models.EventClass
import com.example.fmkinp.models.Status
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class RegistrationViewModel : AndroidViewModel {

    constructor(application: Application) : super(application)

    //private var presenter : MainContractor.Presenter<MainContractor.View>? = null
    private var repository: Repository? = null
    val showSendNumberForm = MutableLiveData<Boolean>()
    val showSendCodeForm = MutableLiveData<Boolean>()
    val showProgressBar = MutableLiveData<Boolean>()
    //val eventLiveData = MutableLiveData<EventClass>()
    val eventLiveData = MediatorLiveData<EventClass>()

    companion object {
        val ACTION_GO_TO_WORK = "registration_viewmodel_action_go_to_work"
        val ACTION_NOTHING = "registration_viewmodel_action_nothing"
    }

    init {
        repository = App.instance.getRepository()!!
        showSendNumberForm.value = true
        showSendCodeForm.value = false
        showProgressBar.value = false

        eventLiveData.addSource(repository?.getNetworkStateAuthorization()!!) { value ->
            eventLiveData.value = getEventsData(value, false)
        }
        eventLiveData.addSource(repository?.getNetworkStateSendCode()!!) { value ->
            eventLiveData.value = getEventsData(value, true)
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository = null
    }

    private var TAG = "RegistrationViewModel"
    /*private var isSendNumberClick = false
    private var isSendCodeClick = false*/

    private lateinit var ow1: LifecycleOwner

    fun getMyUser(token: String) = repository!!.selectMyUser(token!!)

    fun setLifecycle(lifecycleOwner: LifecycleOwner) {
        /*var cm =  getApplication<Application>().applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE);

        var activeNetwork = cm. getActiveNetworkInfo();*/
        //var isConnected = activeNetwork.isConnectedOrConnecting();
        ow1 = lifecycleOwner
        this.repository = repository
        /*this.repository?.getMyUserLiveData()?.observe(lifecycleOwner, Observer { user ->
             user?.let { }
        })*/

        this.repository?.getNetworkStateAuthorization()
            ?.observe(lifecycleOwner, Observer { networkState ->
                networkState?.let {
                    when (networkState.status) {
                        Status.RUNNING -> {
                            showProgressBar.value = true
                        }
                        Status.SUCCESS -> {
                            showProgressBar.value = false
                            showSendNumberForm.value = false
                            showSendCodeForm.value = true
                        }
                        else -> {
                            showProgressBar.value = false
                            eventLiveData.postValue(EventClass(Event.ERROR, networkState.msg))
                        }
                        /* else -> { // �������� �������� �� ����
                             showProgressBar.value=false
                         }*/
                    }
                }
            })
        this.repository?.getNetworkStateSendCode()
            ?.observe(lifecycleOwner, Observer { networkState ->
                networkState?.let {
                    when (networkState.status) {
                        Status.RUNNING -> {
                            showProgressBar.value = true
                        }
                        Status.SUCCESS -> {
                            showProgressBar.value = false
                            //eventLiveData.postValue(EventClass(Event.ACTION, ACTION_GO_TO_WORK))
                        }
                        else -> {
                            showProgressBar.value = false
                            //eventLiveData.postValue(EventClass(Event.ERROR, networkState.msg))
                        }
                    }
                }
            })
    }

    private fun getEventsData(networkState: NetworkState, isSendCode:Boolean): EventClass {

        val state = networkState
        state?.let {
            when (state.status) {
                Status.RUNNING -> {
                    showProgressBar.value = true
                    return EventClass(Event.ACTION, ACTION_NOTHING)
                }
                Status.SUCCESS -> {
                    showProgressBar.value = false
                    if(isSendCode){
                        return EventClass(Event.ACTION, ACTION_NOTHING)
                    }
                    else{
                        showSendNumberForm.value = false
                        showSendCodeForm.value = true
                        return EventClass(Event.ACTION, ACTION_NOTHING)
                    }
                    
                }
                else -> {
                    showProgressBar.value = false
                    return EventClass(Event.ERROR, state.msg)
                }
            }
        }

/*
        if(!workState.isNullOrEmpty()){
            if (nwState?.status == Status.SUCCESS && workState[0].state == WorkInfo.State.SUCCEEDED)
                return EventClass(Event.ACTION, ACTION_GO_TO_LIST_DETAIL)
            else
                return EventClass(Event.ERROR, nwState.msg)
        }*/
        return EventClass(Event.ACTION, ACTION_NOTHING)
    }

    fun setShowProgressBar(isShow:Boolean){
        showProgressBar.value = isShow
    }

    fun authorization(login: String, pasw: String, token: String) {
        //isSendNumberClick = true
        //val phone = number.replace("[^\\d]".toRegex(), "")
        if (!login.isNullOrBlank() && !pasw.isNullOrBlank())
            repository?.authorization(login, pasw, token)
        else
            eventLiveData.postValue(EventClass(Event.ERROR, "Неверный формат номера"))
    }

    fun sendAuthCode(code: String, token: String) {
        //isSendCodeClick=true
        viewModelScope.launch(Dispatchers.IO) {
            repository?.sendRegistrationCode(code, token)
        }
    }

    /*fun checkAuthentification(user: UserClass){
         if(repository?.getMyUserLiveData()?.getValue()!=null){
              if(!repository!!.getMyUserLiveData().getValue()!!.token.equals(token)){
                   repository!!.getMyUserLiveData().getValue()?.id?.let {
                        repository!!.updateToken(it, token)
                   }
              }
              else{
                   view?.goToInp()
              }
         }
         else{
              showSendNumberForm=true
         }
    }*/
}