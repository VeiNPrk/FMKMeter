package com.example.fmkinp.Presenters

import android.content.Context
import android.util.Log
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import com.example.fmkinp.App
import com.example.fmkinp.Contractors.MainContractor
import com.example.fmkinp.models.Status
import com.example.fmkinp.models.UserClass
import com.example.fmkinp.Repository
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId

class MainPresenter<V : MainContractor.View> : LifecycleObserver, MainContractor.Presenter<V> {

    private var view: V?=null
    private var TAG = "MainPresenter"
    private var isSendNumberClick = false
    private var isSendCodeClick = false
    override fun isViewAttached(): Boolean {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private var repository : Repository? = null
    private lateinit var ow1: LifecycleOwner

    override fun setRepository(repository: Repository?, lifecycleOwner: LifecycleOwner) {
        ow1 = lifecycleOwner
        this.repository = repository
        this.repository?.getMyUserLiveData()?.observe(lifecycleOwner, Observer { user ->
                user?.let { /*adapter.setWords(it) */}
        })

        this.repository?.getNetworkState()?.observe(lifecycleOwner, Observer { networkState ->
                networkState?.let { 
                    when (networkState.status) {
                        Status.RUNNING -> {print("RUNNING")}
                        Status.SUCCESS -> {
                            if(isSendNumberClick){
                                isSendNumberClick=false
                                view?.showSendNumberForm(false)
                                view?.showSendCodeForm(true)
                            }

                            if(isSendCodeClick){
                                isSendCodeClick=false
                                view?.goToInp()
                            }else
                            {

                            }
                        }
                        Status.FAILED ->{
                            view?.showError(true, networkState.msg)
                        }
                        else -> { // �������� �������� �� ����
                            print("WHEN ELSE")
                        }
                    }
                    /*if(networkState.getStatus()!= Status.RUNNING) {
                        //view.showProgressBar(false);
                    if(isSendNumberClick){
                        isSendNumberClick=false;
                        view.scrollToTop();
                    }*/
                }
                /*else if(repository.getPokemonsPagedList().getValue().size()==0 || isRefreshClick)
                    view.showProgressBar(true);
                if(networkState.getStatus()==Status.FAILED)
                    view.showToastMessage(networkState.getMsg());
                }*/
        })
        //this.repository.getAllData().observe(lifecycleOwner,
    }
    override fun setContext(context: Context) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun attachLifecycle(lifecycle: Lifecycle) {
        lifecycle.addObserver(this)
    }

    override fun detachLifecycle(lifecycle: Lifecycle) {
        lifecycle.removeObserver(this)
    }

    override fun attachView(view: V) {
        this.view=view
    }

    override fun detachView() {
        view = null
    }

    override fun clearFragment() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun setSwitchChartValue(isChecked: Boolean) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun setSeekBarStep(progress: Int, step: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun setSeekBarDelta(progress: Int, delta: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onPresenterDestroy() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun nextSetOnClick() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun prewSetOnClick() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun loadDataOnClick() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun sendNumber(number:String){
        val phone = number.replace("[^\\d]".toRegex(), "")
        if(phone.length==10)
            FirebaseInstanceId.getInstance().instanceId
                    .addOnCompleteListener(OnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            Log.w(TAG, "getInstanceId failed", task.exception)
                            return@OnCompleteListener
                        }

                        // Get new Instance ID token
                        val token = task.result?.token
                       // App.instance.setAppToken(token)
                        isSendNumberClick=true
                       // repository?.sendNumberPhone(number, token)
                        // Log and toast
                        //val msg = getString(R.string.msg_token_fmt, token)
                        Log.d(TAG, token)
                        //Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
                    })
        else
            view?.showError(true,"������������ ������")
    }

    override fun sendAuthCode(code: String) {
        FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w(TAG, "getInstanceId failed", task.exception)
                    return@OnCompleteListener
                }
                val token = task.result?.token
                //App.instance.setAppToken(token)
                //isSendNumberClick=true
                //repository?.sendRegistrationCode(code, token)
                // Log and toast
                //val msg = getString(R.string.msg_token_fmt, token)
                Log.d(TAG, token)
                //Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
            })
    }

    fun checkAuthentification(user: UserClass){
        if(repository?.getMyUserLiveData()?.getValue()!=null){
            FirebaseInstanceId.getInstance().instanceId
                    .addOnCompleteListener(OnCompleteListener { task ->
                        if (!task.isSuccessful) {
                            Log.w(TAG, "getInstanceId failed", task.exception)
                            return@OnCompleteListener
                        }
                        // Get new Instance ID token
                        val token = task.result?.token
                        if(!repository!!.getMyUserLiveData().getValue()!!.token.equals(token)){
                            repository!!.getMyUserLiveData().getValue()?.id?.let {
                                repository!!.updateToken(
                                    it, token)
                            }
                        }
                        else{
                            view?.goToInp()
                        }
                        // Log and toast
                        //val msg = getString(R.string.msg_token_fmt, token)
                        Log.d(TAG, token)
                        //Toast.makeText(baseContext, msg, Toast.LENGTH_SHORT).show()
                    })
            
                
        }
        else{
            view?.showSendNumberForm(true)
        }
    }
}