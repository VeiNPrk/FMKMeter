package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.*
@Entity
data class TypeDetail(
     @PrimaryKey val id:Int,
     val name: String,
     val imgUrl: String?
)
