package com.example.fmkinp.models

/*class DetailSideFrame(
     id:Int,
     type:Int,
     dateControl: Long,
     numDetail: Int,
     yearCreate: Int,
     createFactory:Int,
     resultControl:Int,
     var res : Int
) : Detail(id, type,dateControl, numDetail, yearCreate, createFactory, resultControl){
     
     var afterFactoryRepair :Int = 0

     override fun getSimpleDateStr() = super.getSimpleDateStr()
     //fun getSimpleDateStr() = SimpleDateFormat("dd.MM.yyyy").format(Date(dateControl))
}*/