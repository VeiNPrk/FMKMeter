package com.example.fmkinp.Contractors

import android.content.Context
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import com.example.fmkinp.Repository

interface MainContractor {
    interface View {
        fun showDialog(dialog: DialogFragment)

        fun showToast(message: String)

        fun showError(show:Boolean, message:String)

        fun showSendNumberForm(show :Boolean)

        fun showSendCodeForm(show :Boolean)

        fun goToInp()

        fun goToInpTest()
    }

    interface Presenter<V : MainContractor.View> {

        fun isViewAttached() : Boolean

        fun setContext(context: Context)

        fun setRepository(repository: Repository?, lifecycleOwner: LifecycleOwner)

        fun attachLifecycle(lifecycle: Lifecycle)

        fun detachLifecycle(lifecycle: Lifecycle)

        fun attachView(view: V)

        fun detachView()

        fun clearFragment()

        fun setSwitchChartValue(isChecked: Boolean)

        fun setSeekBarStep(progress: Int, step: Int)

        fun setSeekBarDelta(progress: Int, delta: Int)

        fun onPresenterDestroy()

        fun nextSetOnClick()

        fun prewSetOnClick()

        fun loadDataOnClick()

        fun sendNumber(number:String)

        fun sendAuthCode(code:String)
    }
}