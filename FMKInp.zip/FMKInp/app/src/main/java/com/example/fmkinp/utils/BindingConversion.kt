package com.example.fmkinp.utils

import androidx.databinding.BindingConversion
import androidx.databinding.InverseMethod

object BindingConversion {
        /*@BindingConversion
        @InverseMethod("convertBooleanToInt")
        @JvmStatic fun convertIntToBoolean(checked: Int): Boolean = if(checked==1) true else false

        @BindingConversion
        //
        @JvmStatic fun convertBooleanToInt(checked: Boolean): Int = if(checked) 1 else 0*/
}


