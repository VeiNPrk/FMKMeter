package com.example.fmkinp.models

import androidx.databinding.BaseObservable
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.fmkinp.utils.DateUtils
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*

@Entity
class DetailNum(
    @SerializedName("id_ndt_res")
    @PrimaryKey var id: Int,
    @SerializedName("id_pr")
    val idEntUser: Int,
    @SerializedName("id_man_create")
    val idCreateUser: Int,
    @SerializedName("id_parts")
    val type: Int,
    @SerializedName("dt_controlya")
    var _dateControl: String,
    @SerializedName("number_part")
    var numDetail: String?,
    @SerializedName("god_izg")
    var yearCreate: Int,
    @SerializedName("id_zavods")
    var idFactory: Int,
    @SerializedName("time_create")
    var _timeCreate: String,
    @SerializedName("id_result")
    var resultControl: Int,

    @SerializedName("id_type_def")
    var typeDef: Int,
    @SerializedName("id_zone_def")
    var zoneDef: Int,
    @SerializedName("marka_stal")
    var steel: String?,
    @SerializedName("vm_nk")
    var methodType: String?,
    @SerializedName("type_defectoskopa")
    var defectDetector: String?,
    @SerializedName("l_def")
    var lDef: String?,
    @SerializedName("h_def")
    var hDef: String?,
    @SerializedName("d_def")
    var dDef: String?,
    @SerializedName("razmer_def")
    var sizeDef: String?,
    @SerializedName("name_owner")
    var ownerName: String?,
    @SerializedName("opisanie_remont")
    var descriptRemDef: String?,
    @SerializedName("def_descript")
    var descriptDefect: String?,

    @SerializedName("familiya_i_o_speca")
    var fioSpec: String?,
    @SerializedName("is_new_part")
    var isNew: Int,
    //var isNew:Boolean,
    @SerializedName("is_from_pto")
    var isFromPto: Int,
    @SerializedName("is_from_pto_number")
    var fromPtoNum: Int,
    //var isFromPto:Boolean,
    @SerializedName("is_not_kriterii_01_08_2013")
    //var isNotKrit01082013:Boolean,
    var isNotKrit01082013: Int,
    @SerializedName("when_find")
    var whenFind: Int,
    @SerializedName("is_not_v_zone_nk")
    var isNotVZoneNk: Int,
    @SerializedName("name_zone_not_nk")
    var nameZoneNotNk: String?,
    @SerializedName("isLoaded")
    var isLoaded: Int = 0/*,

    @SerializedName("is_create_update")
    var isCreateUpdate: Int = 0*/

){
    val strResultControl: String
        get() = resultControl.toString()

    var dateControl: Long = 0
        set(value) {
            if(value >0)
                field=value
            else
                field = SimpleDateFormat("dd.MM.yyyy").parse(_dateControl).time
        }
        get()= if(field > 0)
            field
        else
            SimpleDateFormat("dd.MM.yyyy").parse(_dateControl).time

    var timeCreate: Long = 0
        set(value) {
            if(value >0)
                field=value
            else
                field = SimpleDateFormat("dd.MM.yyyy HH:mm:ss").parse(_timeCreate).time
        }
        get()= if(field > 0)
            field
        else
            SimpleDateFormat("dd.MM.yyyy HH:mm:ss").parse(_timeCreate).time
        /*set(value) {
            val date = SimpleDateFormat("dd.MM.yyyy HH:mm:ss").parse(_timeCreate)
            field = date.time
        }*/
    var nameResult:String?=""

    fun getSimpleDateStr() = SimpleDateFormat("dd.MM.yyyy").format(Date(dateControl))

    fun getFirstCharNameResult() = if(!nameResult.isNullOrEmpty()) nameResult?.get(0)?.toUpperCase() else ""

    fun setIsNew(ch : Int){
        isNew=ch
    }
    fun getIsNew1()=isNew

    fun setIsFromPto(pto : Int){
        isFromPto=pto
    }
    fun getIsFromPto1()=isFromPto

    fun setIsNotKrit01082013(krit : Int){
        isNotKrit01082013=krit
    }

    fun setIsNotVZoneNk(vZoneNk : Int){
        isNotVZoneNk=vZoneNk
    }
    fun getIsNotKrit010820131()=isNotKrit01082013

    fun createDefDescript(nameTypeDef:String, nameZoneDef:String){
        descriptDefect=""
        if(whenFind==1){
            descriptDefect+="обнаружен: \"визуально\"; "
            if(!nameTypeDef.isNullOrBlank())
                descriptDefect+="тип дефекта: \"$nameTypeDef\"; "
            if(!nameZoneDef.isNullOrBlank())
                descriptDefect+="зона выявления: \"$nameZoneDef\"; "
            if(!lDef.isNullOrBlank()) 
                descriptDefect+="L=$lDef мм; "
            if(!hDef.isNullOrBlank()) 
                descriptDefect+="H=$hDef мм; "
            if(!dDef.isNullOrBlank()) 
                descriptDefect+="D=$dDef мм; "
            if(!steel.isNullOrBlank()) 
                descriptDefect+="сталь \"$steel\"; "
            if(!ownerName.isNullOrBlank()) 
                descriptDefect+="собственник \"$ownerName\""
        }
        
        if(whenFind==2){
            if(isNotVZoneNk==0) 
                descriptDefect+="обнаружен: \"средствами НК\"; "
            else 
                descriptDefect+="обнаружен: \"вне зоны обязательного НК\"; "

            if(!methodType.isNullOrBlank()) 
                descriptDefect+="вид (метод): \"$methodType\"; "
            if(!nameTypeDef.isNullOrBlank())
                descriptDefect+="тип дефекта: \"$nameTypeDef\"; "
            if(!sizeDef.isNullOrBlank()) 
                descriptDefect+="размер (трещины), мм: \"$sizeDef\"; "

            if(isNotVZoneNk==0) 
                if(!defectDetector.isNullOrBlank()) 
                    descriptDefect+="тип дефектоскопа: \"$defectDetector\"; "

            if(isNotVZoneNk==0){
                if(!nameZoneDef.isNullOrBlank())
                    descriptDefect+="зона выявления: \"$nameZoneDef\"; "
            }
            else 
                descriptDefect+="зона выявления: \"$nameZoneNotNk\"; "

            if(!steel.isNullOrBlank()) 
                descriptDefect+="сталь \"$steel\"; "
            if(!ownerName.isNullOrBlank()) 
                descriptDefect+="собственник \"$ownerName\""

        }
    }
}