package com.example.fmkinp.Views

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import com.example.fmkinp.ControlListRecyclerAdapter
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.ControlListViewModel


class ControlActivity : AppCompatActivity() {
    private val TAG = "ControlActivity"
    //lateinit var binding : ActivityControlBinding
    lateinit var mAdapter : ControlListRecyclerAdapter
    lateinit var viewModel: ControlListViewModel
    var typeDetail = 0

    companion object{
        public val KEY_TYPE_DETAIL = "key_type_detail"

        fun openActivity(context: Context, typeDetail:Int){
            val intent = Intent(context, ControlActivity::class.java)
            intent.putExtra(KEY_TYPE_DETAIL, typeDetail)
            if (!(context is Activity))
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_control)
        /*val inte= intent
        intent.extras?.let{
            typeDetail=it.getInt(KEY_TYPE_DETAIL,0)
        }*/
        //savedInstanceState?.let
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        return super.onCreateOptionsMenu(menu)
    }
}
