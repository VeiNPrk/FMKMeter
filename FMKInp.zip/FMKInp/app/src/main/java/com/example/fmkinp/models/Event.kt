package com.example.fmkinp.models

enum class Event {
    ACTION,
    ERROR
}