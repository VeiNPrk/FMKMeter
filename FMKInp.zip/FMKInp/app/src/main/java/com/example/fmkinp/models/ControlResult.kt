package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
@Entity
class ControlResult(
     @SerializedName("id_res")
     @PrimaryKey val id:Int,
     @SerializedName("name_res") 
     val name:String,
     @SerializedName("id_part") 
     val typeDetail:Int,
     @SerializedName("comment") 
     val comment:String?,
     @SerializedName("order_by_1") 
     val orderBy:Int,
     @SerializedName("isVisible") 
     val isVisible:Int
){
     override fun toString(): String = name
}