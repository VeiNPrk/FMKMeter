package com.example.fmkinp.Views

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.fmkinp.DetailChooseRecyclerAdapter
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.DetailChooseViewModel
import com.example.fmkinp.databinding.ActivityDetailChooseBinding

class DetailChooseActivity : AppCompatActivity(), DetailChooseRecyclerAdapter.DetailControlClickListener {

    lateinit var binding : ActivityDetailChooseBinding
    lateinit var mAdapter : DetailChooseRecyclerAdapter
    lateinit var viewModel:DetailChooseViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_choose)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_detail_choose)
        binding.lifecycleOwner=this
        viewModel = ViewModelProviders.of(this)[DetailChooseViewModel::class.java]
        setRecyclerView()
        viewModel.getChooseDetails().observe(this, Observer { detailsControl ->
            detailsControl?.let { mAdapter.setDetailsData(it) }
        })
    }

    fun setRecyclerView() {
        val mLayoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mAdapter = DetailChooseRecyclerAdapter(this, this)
        binding.rvChooseDetail.setHasFixedSize(true)
        binding.rvChooseDetail.layoutManager = mLayoutManager
        binding.rvChooseDetail.adapter=mAdapter

        val itemDecoration = DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        binding.rvChooseDetail.addItemDecoration(itemDecoration)
        binding.rvChooseDetail.setItemAnimator(DefaultItemAnimator())
    }

    override fun onClick(idDetail: Int) {
        //Toast.makeText(this, "idDetail= $idDetail", Toast.LENGTH_LONG).show()
        ControlActivity.openActivity(this, idDetail)
    }
}
