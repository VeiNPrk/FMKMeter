package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
@Entity
class EntSpecialist(
     @SerializedName("idm")
     @PrimaryKey val id:Int,
     @SerializedName("nm1") 
     val firstName:String,
     @SerializedName("nm2") 
     val secondName:String,
     @SerializedName("nm3") 
     val lastName:String,
     @SerializedName("idpr") 
     val enterprise:Int
){
     override fun toString(): String {
          var inic = ""
          if(!secondName.isNullOrEmpty())
              inic=inic.plus(firstName[0].toUpperCase()).plus(".")
          if(!lastName.isNullOrEmpty())
              inic=inic.plus(secondName[0].toUpperCase()).plus(".")
          return "$firstName $inic"
     }
}