package com.example.fmkinp.viewmodels

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.os.DropBoxManager
import android.service.autofill.Validators.not
import android.util.Log
import android.widget.ArrayAdapter
import androidx.databinding.ObservableBoolean
import androidx.databinding.ObservableField
import androidx.databinding.ObservableInt
import androidx.lifecycle.*
import androidx.lifecycle.Observer
import androidx.work.*
import com.example.fmkinp.App
import com.example.fmkinp.NetworkState
import com.example.fmkinp.R
import com.example.fmkinp.Repository
import com.example.fmkinp.models.*
import com.example.fmkinp.utils.DatePickerDlg
import java.util.*
import com.example.fmkinp.utils.DateUtils
import com.example.fmkinp.utils.NetworkUtils
import com.example.fmkinp.utils.SharedPreferencesUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.concurrent.TimeUnit
import kotlin.collections.ArrayList

class DetailCastViewModel : AndroidViewModel {

    private val _detail = MutableLiveData<DetailNum>()
    val detail: LiveData<DetailNum>
        get() = _detail
    
    val eventLiveData = MediatorLiveData<EventClass>()
    internal val outputWorkInfos: LiveData<List<WorkInfo>>
    val ACTION_GO_TO_LIST_DETAIL = "detailcast_viewmodel_action_go_to_list_detail"
    val ACTION_NOTHING = "detailcast_viewmodel_action_nothing"
    var isFromPto = ObservableBoolean(false)
    var isBrakCheck = ObservableBoolean(false)
    var isRepairCheck = ObservableBoolean(false)
    var isVisibleBeforeNk = ObservableBoolean(true)
    var isEnabledTypeDef = true
    var validationNumDetail = ObservableBoolean(false)
    var validationFioSpec = ObservableBoolean(false)
    var validationYearCreate = ObservableBoolean(false)
    var validationFactory = ObservableBoolean(false)
    var validationSteel = ObservableBoolean(false)
    var validationDefektoskopType = ObservableBoolean(false)
    var validationZone = ObservableBoolean(false)
    var validationDefType = ObservableBoolean(false)
    var validationMethodType = ObservableBoolean(false)
    var validationResult = ObservableBoolean(false)
    var validationNameOwner = ObservableBoolean(false)
    var validationDescrDef = ObservableBoolean(false)
    var resultName = ObservableField<String>()
    var whenFindName = ObservableField<String>()
    var fromPtoStr = ObservableField<String>()
    var fromPtoN:Int=0
    var fromPtoNVrk:Int=0
    var fromPtoNFault:Int=0
    var isNk = ObservableBoolean(false)
    var userId = 0
    var userEnt = 0
    var whenFind = 0
    private val NAME_BRAK = "брак"
    private val NAME_REPAIR = "ремонт"
    val WORK_SAVE_NAME="work_save_name"
    var detailId = 0
    val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
    var defectTypesAll : List<DefectType> = ArrayList()
    var factorys : List<FactoryDetail> = ArrayList()
    val factorysItemPosition = ObservableInt()
    var factoryValue
        get() =
            factorysItemPosition.get()?.let {
                factorys?.get(it-1)?.id
            }
        set(value) {
            val position = factorys?.indexOfFirst {
                it.id == value
            } ?: -1
            if (position != -1) {
                factorysItemPosition.set(position + 1)
            }
        }
    var years : List<Int> = ArrayList()
    val yearsItemPosition = ObservableInt()
    var yearValue
        get() =
            yearsItemPosition.get()?.let {
                years?.get(it-1)
            }
        set(value) {
            val position = years?.indexOfFirst {
                it == value
            } ?: -1
            if (position != -1) {
                yearsItemPosition.set(position + 1)
            }
        }
    var entSpecialists : List<EntSpecialist> = ArrayList()
    val entSpecialistsItemPosition = ObservableInt()
    var entSpecialistValue
        get() =
            entSpecialistsItemPosition.get()?.let {
                entSpecialists?.get(it-1)?.toString()
            }
        set(value) {
            val position = entSpecialists?.indexOfFirst {
                it.toString() == value
            } ?: -1
            if (position != -1) {
                entSpecialistsItemPosition.set(position + 1)
            }
        }
    var defectTypes : List<DefectType> = ArrayList()
    val defectTypesItemPosition = ObservableInt()
    var defectTypeValue
        get() =
            defectTypesItemPosition.get()?.let {
                defectTypes?.get(it-1)?.id
            }
        set(value) {
            val position = defectTypes?.indexOfFirst {
                it.id == value
            } ?: -1
            if (position != -1) {
                defectTypesItemPosition.set(position + 1)
            }
        }
    var defectZones : List<DefectZone> = ArrayList()
    val defectZonesItemPosition = ObservableInt()
    var defectZoneValue
        get() =
        defectZonesItemPosition.get()?.let {
            defectZones?.get(it-1)?.id
            }
        set(value) {
            val position = defectZones?.indexOfFirst {
                it.id == value
            } ?: -1
            if (position != -1) {
                defectZonesItemPosition.set(position + 1)
            }
        }
    var steels : List<Steel> = ArrayList()
    val steelsItemPosition = ObservableInt()
    var steelValue
        get() =
        steelsItemPosition.get()?.let {
            steels?.get(it-1)?.name
            }
        set(value) {
            val position = steels?.indexOfFirst {
                it.name == value
            } ?: -1
            if (position != -1) {
                steelsItemPosition.set(position + 1)
            }
        }
    var methodTypes : List<MethodNkType> = ArrayList()
    val methodTypesItemPosition = ObservableInt()
    var methodTypeValue
        get() =
        methodTypesItemPosition.get()?.let {
            methodTypes?.get(it-1)?.name
            }
        set(value) {
            val position = methodTypes?.indexOfFirst {
                it.name == value
            } ?: -1
            if (position != -1) {
                methodTypesItemPosition.set(position + 1)
            }
        }
    var defDetectorTypes : List<DefectDetectorType> = ArrayList()
    val detectorTypesItemPosition = ObservableInt()
    var detectorTypeValue
        get() =
        detectorTypesItemPosition.get()?.let {
            defDetectorTypes?.get(it-1)?.toString()
            }
        set(value) {
            val position = defDetectorTypes?.indexOfFirst {
                it.toString() == value
            } ?: -1
            if (position != -1) {
                detectorTypesItemPosition.set(position + 1)
            }
        }

    private val workManager = WorkManager.getInstance(getApplication())

    constructor(application: Application) : super(application)

    private var repository: Repository? = null
    var detailNum: DetailNum? = null

    init {
        repository = App.instance.getRepository()!!
        outputWorkInfos = workManager.getWorkInfosForUniqueWorkLiveData(WORK_SAVE_NAME)
        workManager.pruneWork()

        eventLiveData.addSource(repository!!.getNetworkState()) { value ->
            eventLiveData.value = combineEventsData(repository!!.getNetworkState(), outputWorkInfos)
        }
        eventLiveData.addSource(outputWorkInfos) { value ->
            eventLiveData.value = combineEventsData(repository!!.getNetworkState(), outputWorkInfos)
        }
    }

    companion object{
        val KEY_WORK_ID_USER = "key_user_id"
        val KEY_WORK_ENT_USER = "key_user_ent"
    }

    fun initDetail(typeDetail: Int /*, prefs: SharedPreferences?*/) {
        /*userId = prefs?.getInt("my_user_id", 0)!!
        userEnt = prefs?.getInt("my_user_ent", 0)*/
        userId = SharedPreferencesUtils.getInt(getApplication<Application>(), SharedPreferencesUtils.NAME_PREF_USER_ID)
        userEnt = SharedPreferencesUtils.getInt(getApplication<Application>(), SharedPreferencesUtils.NAME_PREF_USER_ENT)
        if (detailNum == null) {
            detailNum = DetailNum(
                0,
                userEnt!!,
                userId!!,
                typeDetail,
                DateUtils.getSimpleDateStr(Date()),
                "",
                0,
                0,
                DateUtils.getSimpleDateTimeStr(Date()),
                0,
                0,
                0,
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                "",
                0,
                0,
                0,
                0,
                0,
                0,
                ""
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        repository = null
    }

    fun getControlResults(typeDetail: Int) = repository!!.getControlResults(typeDetail)

    fun getDetailLiveData(id: Int, lifecycleOwner: LifecycleOwner): LiveData<DetailNum> {
        if (detailId != id) {
            detailId = id
            repository!!.getDetail(detailId).observe(lifecycleOwner, androidx.lifecycle.Observer {
                detailNum = it
                _detail.value = detailNum
            })
        } else
            _detail.value = detailNum

        return detail
    }

    private fun combineEventsData(networkState: MutableLiveData<NetworkState>, workerState: LiveData<List<WorkInfo>>): EventClass {

        val nwState = networkState.value
        val workState = workerState.value
        if(!workState.isNullOrEmpty()){
            if (nwState?.status == Status.SUCCESS && workState[0].state == WorkInfo.State.SUCCEEDED)
                return EventClass(Event.ACTION, ACTION_GO_TO_LIST_DETAIL)
            else if(nwState?.status == Status.FAILED)
                return EventClass(Event.ERROR, nwState!!.msg)
            else
                return EventClass(Event.ACTION, ACTION_NOTHING)
        }
        return EventClass(Event.ACTION, ACTION_NOTHING)
    }

    fun getTypesDefect()=
        (if(isBrakCheck.get()) defectTypesAll.filter { it.brakRemont==0 }
        else if(isRepairCheck.get()) defectTypesAll.filter { it.brakRemont==1 }
        else defectTypesAll).toMutableList()

    fun setFactoryCreate(_factorys : List<FactoryDetail>){
        factorys=_factorys
        factoryValue= detailNum?.idFactory!!
    }

    fun setYearCreate(yearsCreate : List<Int>){
        years=yearsCreate
        yearValue= detailNum?.yearCreate!!
    }

    fun setEntSpecialist(specialists : List<EntSpecialist>){
        entSpecialists=specialists
        entSpecialistValue= detailNum?.fioSpec!!
    }

    fun setTypesDefect(){
        defectTypes=getTypesDefect()
        defectTypeValue = detailNum?.typeDef!!
    }

    fun setZonesDefect(zones : List<DefectZone>){
        defectZones=zones
        defectZoneValue= detailNum?.zoneDef!!
    }

    fun setSteel(_steels : List<Steel>){
        steels=_steels
        steelValue= detailNum?.steel.toString()
    }

    fun setMethodNkTypes(methodNkTypes : List<MethodNkType>){
        methodTypes=methodNkTypes
        methodTypeValue= detailNum?.methodType.toString()
    }

    fun setDefectDetectorTypes(detectorTypes : List<DefectDetectorType>){
        defDetectorTypes=detectorTypes
        detectorTypeValue = detailNum?.defectDetector.toString()
    }

    fun setDateControlToDetail(date: Calendar) {
        detailNum?.dateControl = date.timeInMillis
        _detail.value = detailNum
    }

    fun getDateDialog(listener: DatePickerDlg.OnDateCompleteListener, date: Date?): DatePickerDlg {
        val dlg = DatePickerDlg.newInstance(date)
        dlg.setListener(listener)
        return dlg
    }

    fun getFactorysCreate(typeDetail: Int) = repository!!.getFactorysDetail(typeDetail)

    fun getEntSpecialists() = repository!!.getEntSpecialsts()

    fun getDefectTypes(typeDetail :Int) = repository!!.getDefectTypes(typeDetail)

    fun getDefectZones(typeDetail :Int) = repository!!.getDefectZones(typeDetail)

    fun getSteels() = repository!!.getSteels()

    fun getMethodNkTypes(typeDetail :Int) = repository!!.getMethodNkTypes(typeDetail)

    fun getDefectDetectorTypes() = repository!!.getDefectDetectorTypes()

    /*fun setFactoryCreateToDetail(idFactory: Int) {
        detailNum?.idFactory = idFactory
        _detail.value = detailNum
    }*/

    /*fun setYearCeateToDetail(year: Int) {
        detailNum?.yearCreate = year
        _detail.value = detailNum
    }*/

    /*fun setFioSpecToDetail(fioSpec: String) {
        detailNum?.fioSpec = fioSpec
        _detail.value = detailNum
    }*/

    fun setResultControl(result: ControlResult, checked: Boolean) {
        if (checked){
            checkResultControl(result)
            detailNum?.resultControl = result.id
        }
    }

    fun checkResultControl(result: ControlResult?) {
        when (result?.name) {
            NAME_BRAK->{
                resultName.set(NAME_BRAK.capitalize())
                isBrakCheck.set(true)
                isRepairCheck.set(false)
                setTypesDefect()
            }
            NAME_REPAIR->{
                resultName.set(NAME_REPAIR.capitalize())
                isBrakCheck.set(false)
                isRepairCheck.set(true)
                isEnabledTypeDef=true
                setTypesDefect()
            }
            else->{
                resultName.set(result?.name?.capitalize())
                isBrakCheck.set(false)
                isRepairCheck.set(false)
                //isEnabledTypeDef=true
            }
        }
    }

    fun checkWhenFind(whenFind: Int) {
        when (whenFind) {
            1->{
                whenFindName.set(getApplication<Application>().getString(R.string.tv_tittle_visible_before_nk))
                isVisibleBeforeNk.set(true)
                isNk.set(false)
            }
            2->{
                whenFindName.set(getApplication<Application>().getString(R.string.tv_tittle_visible_nk))
                isVisibleBeforeNk.set(false)
                isNk.set(true)
            }
            else->{
                whenFindName.set("")
                isVisibleBeforeNk.set(false)
                isNk.set(false)
            }
        }
    }

    fun setFault(isVrk:Boolean, value:Int){
        if(isVrk)
            fromPtoNVrk=value
        else{
            fromPtoNFault = value
        }
        fromPtoN = fromPtoNVrk*10+fromPtoNFault
    }

    fun checkedChangeOutZoneNk(isChecked:Boolean){
        detailNum?.isNotVZoneNk = if (isChecked) 1 else 0
        if(!isChecked)
            defectTypeValue=1
        //else
    }

    fun checkedChangeFromPto(isChecked:Boolean){
        isFromPto.set(isChecked)
        detailNum?.isFromPto = if (isChecked) 1 else 0
    }

    fun getVrkFault():Array<Int?>{
        var vrk = detailNum?.fromPtoNum?.div(10)
        var fault = detailNum?.fromPtoNum?.rem(10)
        if(vrk!! > 4)
            vrk=4
        if(fault!! > 3)
            fault=0
        return arrayOf(vrk,fault)
    }

    fun initVrkFaultStr(){
        val vrkFault = getVrkFault()
        val strVrk = if(vrkFault[0]!! >0) getApplication<Application>().resources.getStringArray(R.array.arr_vrks)[vrkFault[0]!! -1] else ""
        val strFault = if(vrkFault[1]!!>0) getApplication<Application>().resources.getStringArray(R.array.arr_faults)[vrkFault[1]!!-1] else ""
        val str = "$strVrk $strFault"
        fromPtoStr.set(str)
    }

    private fun validation():Boolean{
        //var k =0
        validationFactory.set(!validationItemPosition(factorysItemPosition.get()))
        if(validationFactory.get()) return false
        validationYearCreate.set(!validationItemPosition(yearsItemPosition.get()))
        if(validationYearCreate.get()) return false
        validationNumDetail.set(!validationString(detailNum?.numDetail))
        if(validationNumDetail.get()) return false
        validationResult.set(!validationResult(detailNum?.resultControl))
        if(validationResult.get()) return false
        validationNameOwner.set(!validationString(detailNum?.ownerName))
        validationDescrDef.set(!validationString(detailNum?.descriptRemDef))
        validationSteel.set(!validationItemPosition(steelsItemPosition.get()))
        validationDefektoskopType.set(!validationItemPosition(detectorTypesItemPosition.get()))
        validationZone.set(!validationItemPosition(defectZonesItemPosition.get()))
        validationDefType.set(!validationItemPosition(defectTypesItemPosition.get()))
        validationMethodType.set(!validationItemPosition(methodTypesItemPosition.get()))
        if(isBrakCheck.get()){
            if(validationNameOwner.get()) return false
            if(validationDefType.get()) return false
            if(validationZone.get()) return false
            if(validationSteel.get()) return false
            if(isNk.get()){
                if(validationDefektoskopType.get()) return false
                if(validationMethodType.get()) return false
            }
        }
        if(isRepairCheck.get()){
            if(validationDescrDef.get()) return false
            if(validationDefType.get()) return false
            if(validationZone.get()) return false
        }
        validationFioSpec.set(!validationItemPosition(entSpecialistsItemPosition.get()))
        if(validationFioSpec.get()) return false



        return true
    }

    private fun validationString(str:String?)= str.isNullOrBlank().not()

    private fun validationResult(result:Int?)= result!! >0

    private fun validationItemPosition(position : Int) = position > 0

    fun isEditableDetail() = DateUtils.is24HourInterval(detailNum?.timeCreate!!)

    fun saveDetail() {
        if(validation()){
            val userData = Data.Builder()
                .putInt(KEY_WORK_ID_USER, userId)
                .putInt(KEY_WORK_ENT_USER, userEnt)
                .build()
            val simpleRequest = OneTimeWorkRequestBuilder<MyWorker>()
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 2, TimeUnit.SECONDS)
                .setInputData(userData)
                .build()
            //workManager.enqueueUniqueWork(WORK_SAVE_NAME, ExistingWorkPolicy.KEEP, simpleRequest)

            if(isVisibleBeforeNk.get())
                whenFind = 1
            else if(isNk.get())
                whenFind = 2
            else whenFind = 0


            val date = Date()
            detailNum?._dateControl = detailNum!!.getSimpleDateStr()
            detailNum?.dateControl = DateUtils.getDateFromString(detailNum!!._dateControl).time
            detailNum?.isLoaded = 0
            detailNum?.idFactory=factoryValue
            detailNum?.yearCreate=yearValue
            detailNum?.fioSpec=entSpecialistValue
            detailNum?.typeDef = defectTypeValue
            detailNum?.zoneDef = defectZoneValue
            detailNum?.steel = steelValue
            detailNum?.methodType = methodTypeValue
            detailNum?.defectDetector = detectorTypeValue
            detailNum?.whenFind = whenFind
            detailNum?.fromPtoNum = fromPtoN
            if(isBrakCheck.get() /*|| isRepairCheck.get()*/)
                detailNum?.createDefDescript(defectTypes?.get(defectTypesItemPosition.get())?.name, defectZones.get(defectZonesItemPosition.get()).name)

            /*viewModelScope.launch(Dispatchers.IO) {
                detailNum?.let {
                    try {
                        if (it.id > 0) {
                            repository!!.updateCastDetail(it)
                        } else {
                            var maxId = repository!!.getMaxId()
                            maxId++
                            it.id = maxId
                            it.timeCreate = date.time
                            it._timeCreate = DateUtils.getSimpleDateTimeStr(date)
                            repository!!.insertCastDetail(it)
                        }
                        workManager.enqueueUniqueWork(WORK_SAVE_NAME, ExistingWorkPolicy.KEEP, simpleRequest)
                        //eventLiveData.postValue(EventClass(Event.ACTION, ACTION_GO_TO_LIST_DETAIL))
                    } catch (ex: Exception) {
                        eventLiveData.postValue(EventClass(Event.ERROR, ex.message.toString()))
                    }
                }
                Log.d("coroutine", "initData3")
            }*/
        }
        else{
            eventLiveData.postValue(EventClass(Event.ERROR, "Заполните все обязательные поля!"))
        }
    }

    fun getRepository() = repository
}