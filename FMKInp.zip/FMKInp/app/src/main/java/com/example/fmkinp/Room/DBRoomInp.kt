package com.example.fmkinp.Room

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.fmkinp.models.*

@Database(entities = [
    UserClass::class,
    DetailNum::class,
    TypeDetail::class,
    FactoryDetail::class,
    ControlResult::class,
    EntSpecialist::class,
    DefectType::class,
    DefectZone::class,
    Steel::class,
    MethodNkType::class,
    DefectDetectorType::class
], version = 1)
abstract class DBRoomInp : RoomDatabase() {
    abstract fun inpDao(): DaoInp
}