package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
@Entity
class MethodNkType(
     @SerializedName("id")
     @PrimaryKey val id:Int,
     @SerializedName("type_part") 
     val typeDetail:Int,
     @SerializedName("name") 
     val name:String
){
     override fun toString() = name
}