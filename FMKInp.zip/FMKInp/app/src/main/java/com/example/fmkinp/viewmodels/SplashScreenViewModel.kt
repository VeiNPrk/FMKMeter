package com.example.fmkinp.viewmodels

import android.app.Application
import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.*
import com.example.fmkinp.App
import com.example.fmkinp.Repository
import com.example.fmkinp.R
import com.example.fmkinp.models.Event
import com.example.fmkinp.models.EventClass
import com.example.fmkinp.models.Status
import com.example.fmkinp.models.UserClass
import com.example.fmkinp.utils.DateUtils
import com.example.fmkinp.utils.NetworkUtils
import com.example.fmkinp.utils.SharedPreferencesUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SplashScreenViewModel : AndroidViewModel {

    constructor(application: Application) : super(application)

    private var repository: Repository? = null
    var message = ""
    var isVisibleProgress = false
    var isVisibleNoConnection = false
    var eventLiveData = MutableLiveData<EventClass>()
    lateinit var lyfecycleOwner: LifecycleOwner

    //companion object {
        val ACTION_GO_TO_REGISTRATION = "splash_viewmodel_action_go_to_reg"
        val ACTION_GO_TO_WORK = "splash_viewmodel_action_go_to_work"

    //}

    init {
        repository = App.instance.getRepository()!!
    }


    fun setLifecycle(lifecycleOwner: LifecycleOwner) {
        this.lyfecycleOwner = lifecycleOwner
    }

    private fun observeNetworkState() {
        repository!!.getNetworkState().observe(lyfecycleOwner, Observer { networkState ->
            when (networkState.status) {
                Status.RUNNING -> {
                    Log.d("coroutine", "Status.RUNNING")
                    isVisibleProgress = true
                    message = networkState.msg
                }
                Status.SUCCESS -> {
                    Log.d("coroutine", "Status.SUCCESS")
                    isVisibleProgress = false
                    //goToLiveData.value = 1
                }
                Status.FAILED -> {
                    Log.d("coroutine", "Status.FAILED")
                    isVisibleProgress = false
                    message = networkState.msg
                }
                else -> {
                    isVisibleProgress = false
                    message = "wrong"
                }
            }
        })
    }

    fun checkConnection(){
        if(!NetworkUtils.isNetworkAvailable(getApplication())) {
            isVisibleNoConnection = true
            isVisibleProgress = false
            message = getApplication<Application>().getString(R.string.no_connection)
            eventLiveData.value = EventClass(Event.ERROR, NetworkUtils.ERROR_NO_CONNECTION)
        }
    }

    fun getMyUser(token: String /*, editor: SharedPreferences.Editor*/) {
        DateUtils.getLastNYears(50)
        observeNetworkState()
        repository!!.selectMyUser(token!!).observe(lyfecycleOwner, Observer { user ->
            val userTest = UserClass(27,"",192,"")
            SharedPreferencesUtils.setUser(getApplication<Application>(), userTest)
            /*editor.putInt("my_user_id", userTest.id)
            editor.apply()
            editor.putInt("my_user_ent", userTest.idEnt)
            editor.apply()*/
            initData(userTest)
            /*if(user!=null)
                initData(user)
            else
                if(NetworkUtils.isNetworkAvailable(getApplication()))
                    eventLiveData.value= EventClass(Event.ACTION, ACTION_GO_TO_REGISTRATION)
                else {
                    isVisibleNoConnection=true
                    isVisibleProgress=false
                    message=getApplication<Application>().getString(R.string.no_connection)
                    eventLiveData.value = EventClass(Event.ERROR, NetworkUtils.ERROR_NO_CONNECTION)

                }*/
        })
    }

    override fun onCleared() {
        super.onCleared()
        repository = null
    }

    fun getNetworkState() = repository!!.getNetworkState()

    fun initData(user: UserClass) {
        Log.d("coroutine", "initData1")
        viewModelScope.launch(Dispatchers.IO) {
            Log.d("coroutine", "initData2")
            if(NetworkUtils.isNetworkAvailable(getApplication())) {
                repository!!.syncronizeNsiData(user.idEnt)
                repository!!.syncronizeData(user.id, user.idEnt)
            }
            Log.d("coroutine", "initData2.1")
            eventLiveData.postValue(EventClass(Event.ACTION, ACTION_GO_TO_WORK))
            Log.d("coroutine", "initData3")
        }
        Log.d("coroutine", "initData4")
    }
}