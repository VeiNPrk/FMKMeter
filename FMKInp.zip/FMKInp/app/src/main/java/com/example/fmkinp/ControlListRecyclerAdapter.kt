package com.example.fmkinp

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.example.fmkinp.databinding.RvDetailMaketBinding
import com.example.fmkinp.models.DetailNum


class ControlListRecyclerAdapter(_context: Context, val detailControlClickListener: ControlListClickListener) : RecyclerView.Adapter<ControlListRecyclerAdapter.ControlListViewHolder>(){

    lateinit var context:Context;
    //private lateinit var detailControlClickListener : DetailControlClickListener;
    var data:List<DetailNum> = ArrayList<DetailNum>()
    interface ControlListClickListener {
        fun onClick(idDetail : Int)
        //void onDeleteClick(PictureClass picture);
    }

    class ControlListViewHolder(var binding: RvDetailMaketBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(detailControl: DetailNum) {
            binding.setVariable(BR.detail, detailControl)
            //binding.detail=detailControl!!
            binding.executePendingBindings()
        }
    }

    fun setDetailsData(details: List<DetailNum>){
        data=details
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ControlListViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        //val bind = DataBindingUtil.in
        val binding: RvDetailMaketBinding = DataBindingUtil.inflate(inflater, R.layout.rv_detail_maket, parent, false)
        val viewHolder = ControlListViewHolder(binding)
        return viewHolder
    }

    override fun onBindViewHolder(holder : ControlListViewHolder, i : Int ) {
         //val detail = data.get(i);
        holder.bind(data.get(i))
        holder.binding.root.setOnClickListener {
            detailControlClickListener.onClick(data.get(i).id)
        }
    }

    override fun getItemCount() = data.size


}

