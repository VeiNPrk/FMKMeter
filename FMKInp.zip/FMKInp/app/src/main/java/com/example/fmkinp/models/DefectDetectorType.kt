package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.util.*
@Entity
class DefectDetectorType(
     @SerializedName("id_snk")
     @PrimaryKey val id:Int,
     @SerializedName("id_model") 
     val idModel:Int,
     @SerializedName("zav_num") 
     val factoryNum:String,
     @SerializedName("type_sred") 
     val name:String
){
     override fun toString(): String {
          return "$name (���.� $factoryNum)"
     }
}