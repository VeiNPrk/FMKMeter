package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.util.*
@Entity
class Steel(
     @SerializedName("id_stal")
     @PrimaryKey val id:Int,
     @SerializedName("name_stal") 
     val name:String
){
     override fun toString()=name
     }