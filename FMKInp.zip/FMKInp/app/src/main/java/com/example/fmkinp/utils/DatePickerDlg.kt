package com.example.fmkinp.utils

import android.app.DatePickerDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.DatePicker
import androidx.fragment.app.DialogFragment
import java.util.*

class DatePickerDlg: DialogFragment(), DatePickerDialog.OnDateSetListener
{
    companion object{
        val KEY_DATE="key_date"
        fun newInstance(date:Date?):DatePickerDlg{
            val args = Bundle()
            args.putSerializable(KEY_DATE, date)
            val fragment = DatePickerDlg()
            fragment.arguments=args
            return fragment
        }
    }
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        val date:Date? = arguments?.getSerializable(KEY_DATE) as Date
        val c = Calendar.getInstance()
        date?.let{c.time=date}
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)
        return DatePickerDialog(activity,this,year,month,day)
    }

    override  fun onDateSet(view: DatePicker, year:Int, month:Int, day:Int)
    {
        val calendar= Calendar.getInstance()
        calendar.set(Calendar.YEAR, year)
        calendar.set(Calendar.MONTH, month)
        calendar.set(Calendar.DAY_OF_MONTH, day)
        //onDateComplete()
        this.mListener!!.onDateComplete(calendar);
    }

    fun setListener(listener:OnDateCompleteListener){
        mListener=listener
    }

    interface OnDateCompleteListener {
        fun onDateComplete( time:Calendar)
    }

    private var mListener: OnDateCompleteListener? = null

    // make sure the Activity implemented it
    /*override fun onAttach(activity: Context) {
        super.onAttach(activity)
        try {
            this.mListener = targetFragment as OnDateCompleteListener
        } catch (e: ClassCastException) {
            throw ClassCastException("$activity must implement OnCompleteListener")
        }
    }*/

    override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    //private var  mListener:OnDateCompleteListener=null;

    // make sure the Activity implemented it
    /*override fun onAttach(activity: Activity) {
        super.onAttach(activity);
        try {
            this.mListener = (OnDateCompleteListener)activity
        }
        catch (e:ClassCastException) {
            throw ClassCastException(activity.toString() + " must implement OnCompleteListener");
        }
    }*/
}