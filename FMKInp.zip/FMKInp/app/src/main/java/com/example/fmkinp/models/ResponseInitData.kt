package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.*
class ResponseInitData(
     val isSucces : Int,
     val message : String,
     val types : List<TypeDetail>,
     val factorys : List<FactoryDetail>,
     val results : List<ControlResult>,
     val specialists : List<EntSpecialist>,
     val typesDeffect : List<DefectType>,
     val zones : List<DefectZone>,
     val steel : List<Steel>,
     val typesMethodNk : List<MethodNkType>,
     val typesDefectDetector : List<DefectDetectorType>
)