package com.example.fmkinp.models

enum class Status {
    RUNNING,
    SUCCESS,
    FAILED
}