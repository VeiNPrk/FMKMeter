package com.example.fmkinp

import com.example.fmkinp.InpApi
import android.app.Application
import android.content.Context
import androidx.room.Room
import com.example.fmkinp.Room.DBRoomInp
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

public class App : Application() {

    //private val instance: App
    
    public val MAINURL_API="http://sert-pknk-ru.1gb.ru"
    private var database: DBRoomInp? = null
    private var repository: Repository? = null
    private lateinit var retrofit : Retrofit
    private lateinit var inpApi:InpApi

    companion object {
        lateinit var instance: App
            private set
    }
/*
    init{
        instance = this
    }*/

   // private var appToken :String? = "";

    val appContext: App
        get() = applicationContext as App

    
    override fun onCreate() {
        super.onCreate()
        instance = this
        database = Room.databaseBuilder(this, DBRoomInp::class.java, "database")
            .build()
        repository = Repository()
        val gson = GsonBuilder().setLenient().create()
        retrofit = Retrofit.Builder()
                .baseUrl(MAINURL_API)
                 .addConverterFactory(GsonConverterFactory.create(gson))
                .build()
        inpApi = retrofit.create(InpApi::class.java)
    }

    fun getInstance(): App {
        return instance
    }

    fun getApi() = inpApi

    fun getDatabase() = database

    fun getRepository(): Repository? {
        return repository
    }

    /*fun getAppToken() = appToken

    fun setAppToken(token:String?){
        appToken=token
    }*/
    
}