package com.example.fmkinp.Views

import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.ViewModelProviders
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.DetailNotNumViewModel
import com.example.fmkinp.databinding.FragmentDetailNotnumEditBinding

class DetailDefaultFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState:Bundle?):View? {
        return inflater.inflate(R.layout.fragment_detail_default, container, false)
    }


}
