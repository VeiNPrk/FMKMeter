package com.example.fmkinp.models
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName
import java.text.SimpleDateFormat
import java.util.*
@Entity(primaryKeys = arrayOf("id", "brakRemont"))
class DefectType(
     @SerializedName("id_tdef")
     val id:Int,
     @SerializedName("brak_remont") 
     val brakRemont:Int,
     @SerializedName("id_part") 
     val typeDetail:Int,
     @SerializedName("name_tdef") 
     val name:String
){
     override fun toString()=name
}