package com.example.fmkinp.Views

import android.os.Bundle
import androidx.lifecycle.ViewModelProviders
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.fmkinp.ControlListRecyclerAdapter
import com.example.fmkinp.R
import com.example.fmkinp.viewmodels.ControlListViewModel
//import com.example.fmkinp.databinding.FragmentControlListBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ControlListFragment : Fragment(), ControlListRecyclerAdapter.ControlListClickListener {
    private val TAG = "ControlActivity"
    //lateinit var binding : FragmentControlListBinding
   // lateinit var binding : FragmentControlListBinding
    lateinit var mAdapter : ControlListRecyclerAdapter
    lateinit var viewModel: ControlListViewModel
    lateinit var mview:View
    lateinit var rv :RecyclerView
    lateinit var fab:FloatingActionButton
    var typeDetail = 0
    var isTablet:Boolean = false

    //var detailType=0

    /*companion object{
        private val KEY_TYPE_DETAIL = "key_type_detail"

        fun openActivity(context: Context, typeDetail:Int){
            val intent = Intent(context, ControlActivity.javaClass);
            intent.putExtra(KEY_TYPE_DETAIL, typeDetail);
            if (!(context is Activity))
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }*/

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        activity?.intent?.extras?.let {
            typeDetail=it.getInt(ControlActivity.KEY_TYPE_DETAIL,0)
        }
        isTablet = context!!.resources.getBoolean(R.bool.isTablet)
        mview  = when {
            isTablet -> {
                /*view = */inflater.inflate(R.layout.fragment_control_list_tablet, container, false)
                //binding = DataBindingUtil.inflate(inflater, R.layout.fragment_control_list_tablet, container, false);
                //displayMasterDetailLayout(view)
            }
            else -> {
                /*view = */inflater.inflate(R.layout.fragment_control_list, container, false)
                //binding = DataBindingUtil.inflate(inflater, R.layout.fragment_control_list, container, false);
                //displaySingleLayout(view)
            }
        }
        /*if(isTablet){
            val navHostFragment = childFragmentManager.findFragmentById(R.id.detail_nav_container) as NavHostFragment
            navHostFragment.navController.navigate(R.id.detailDefaultFragment)
        }*/
        //binding.lifecycleOwner=this
        rv = mview.findViewById(R.id.rv_control_detail)
        fab = mview.findViewById(R.id.fab_add_detail)

        return mview
        //view = binding.root
        //return binding.root
    }


    override fun onActivityCreated( savedInstanceState:Bundle?) {
        super.onActivityCreated(savedInstanceState);
        /*val vm = ViewModelProvider(this, SavedStateVMFactory(this))
            .get(SavedStateViewModel::class.java)*/
        viewModel = ViewModelProviders.of(this)[ControlListViewModel::class.java]
        viewModel.initControlResults(this, typeDetail)
        setRecyclerView()
        fab.setOnClickListener(View.OnClickListener {
            onClickAddDetail()
        })
        val prefs = context?.getSharedPreferences("TOKEN_PREF", AppCompatActivity.MODE_PRIVATE)
        val myUserId = prefs?.getInt("my_user_id",0)
        viewModel.getControlDetails(typeDetail, myUserId!!).observe(this, Observer { details ->
            details?.let { mAdapter.setDetailsData(viewModel.addingResult(it)) }
        })
    }

    /*private fun initDetailData(){
        viewModel.getControlDetails(typeDetail)?.let { mAdapter.setDetailsData(it) }
    }*/


    fun setRecyclerView() {
        val mLayoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        mAdapter = context?.let { ControlListRecyclerAdapter(it, this) }!!
        rv.setHasFixedSize(true)
        rv.layoutManager = mLayoutManager
        rv.adapter=mAdapter

        val itemDecoration = DividerItemDecoration(context, DividerItemDecoration.VERTICAL);
        rv.addItemDecoration(itemDecoration)
        rv.setItemAnimator(DefaultItemAnimator())
        //initDetailData()
    }

  /*  private fun displaySingleLayout(view: View) {
        view.findViewById<TextView>(R.id.account_textview).setOnClickListener(
            Navigation.createNavigateOnClickListener(R.id.action_profile_fragment_to_fragment_account)
        )
        view.findViewById<TextView>(R.id.notifications_textview).setOnClickListener(
            Navigation.createNavigateOnClickListener(R.id.action_profile_fragment_to_fragment_notifications)
        )
        view.findViewById<TextView>(R.id.settings_textview).setOnClickListener(
            Navigation.createNavigateOnClickListener(R.id.action_profile_fragment_to_fragment_settings)
        )
    }

    private fun displayMasterDetailLayout(view: View) {
        val navHostFragment =
            childFragmentManager.findFragmentById(R.id.profile_nav_container) as NavHostFragment

        view.findViewById<TextView>(R.id.account_textview).setOnClickListener {
            navHostFragment.navController.navigate(R.id.fragment_account)
        }

        view.findViewById<TextView>(R.id.notifications_textview).setOnClickListener {
            navHostFragment.navController.navigate(R.id.fragment_notifications)
        }

        view.findViewById<TextView>(R.id.settings_textview).setOnClickListener {
            navHostFragment.navController.navigate(R.id.fragment_settings)
        }
    }*/
    private fun onClickAddDetail(){
      when {
          isTablet -> {
              val navHostFragment = childFragmentManager.findFragmentById(R.id.detail_nav_container) as NavHostFragment
              val bundleToTransfer = Bundle()
              bundleToTransfer.putInt("key_id_detail", 0)
              bundleToTransfer.putInt("key_type_detail", typeDetail)
              navHostFragment.navController.navigate(R.id.detailCastEditFragment, bundleToTransfer)
          }
          else -> {
              val action = ControlListFragmentDirections.actionControlListFragmentToDetailCastEditFragment(0, typeDetail)
              mview?.let { Navigation.findNavController(it).navigate(action) }!!
          }
      }
  }

    override fun onClick(idDetail: Int) {
        when {
            isTablet -> {
                val navHostFragment = childFragmentManager.findFragmentById(R.id.detail_nav_container) as NavHostFragment
                val bundleToTransfer = Bundle()
                bundleToTransfer.putInt("key_id_detail", idDetail)
                bundleToTransfer.putInt("key_type_detail", typeDetail)
                navHostFragment.navController.navigate(R.id.detailCastViewFragment, bundleToTransfer)
            }
            else -> {
                val action = ControlListFragmentDirections.actionControlListFragmentToDetailCastViewFragment(idDetail, typeDetail)
                mview?.let { Navigation.findNavController(it).navigate(action) }!!
            }
        }
    }

}
