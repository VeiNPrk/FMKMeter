package com.example.fmkinp.Views

import com.example.fmkinp.R
import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.util.TypedValue
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import android.widget.ArrayAdapter
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import com.example.fmkinp.BR
import com.example.fmkinp.databinding.FragmentDetailCastEditBinding
import com.example.fmkinp.models.*
import com.example.fmkinp.utils.Converter
import com.example.fmkinp.utils.DatePickerDlg
import com.example.fmkinp.utils.DateUtils
import com.example.fmkinp.utils.NothingSelectedSpinnerAdapter
import com.example.fmkinp.viewmodels.DetailCastViewModel
import java.util.*


class DetailCastEditFragment : Fragment(), DatePickerDlg.OnDateCompleteListener {
    private val TAG = "DetailCastEditFragment"
    lateinit var binding: FragmentDetailCastEditBinding
    lateinit var viewModel: DetailCastViewModel
    private var yearsCreate: List<Int> = ArrayList<Int>()
    var detailId = 0
    var typeDetail = 0
    var isTablet: Boolean = false
    var isLoadedNsi = true
    var defectTypes : MutableList<DefectType> = ArrayList()
    var adapterDefectType: ArrayAdapter<DefectType>? = null
    var nothingAdapterDefectType: NothingSelectedSpinnerAdapter?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        setHasOptionsMenu(true)
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_detail_cast_edit, container, false)
        binding.lifecycleOwner = this
        activity?.intent?.extras?.let {
            detailId = it.getInt("key_id_detail", 0)
            typeDetail = it.getInt("key_type_detail", 0)
        }
        isTablet = context!!.resources.getBoolean(R.bool.isTablet)
        detailId = arguments?.let { it.getInt("key_id_detail", 0) }!!
        if (detailId == 0)
            detailId = arguments?.let { it.getInt("idDetail", 0) }!!

        typeDetail = arguments?.let { it.getInt("key_type_detail", 0) }!!
        if (typeDetail == 0)
            typeDetail = arguments?.let { it.getInt("typeDetail", 0) }!!

        //val prefs = context?.getSharedPreferences("TOKEN_PREF", AppCompatActivity.MODE_PRIVATE)
        viewModel = ViewModelProviders.of(this)[DetailCastViewModel::class.java]
        viewModel.initDetail(typeDetail/* , prefs*/)
        binding.setVariable(BR.viewModel, viewModel)
        binding.executePendingBindings()
        binding.tvDateControl.setOnClickListener {
            showDatePickerDialog(Date(viewModel.detailNum!!.dateControl))
        }
        binding.includeNotValid.rbVisibleBeforeNk.setOnCheckedChangeListener { buttonView, isChecked ->
            viewModel.isVisibleBeforeNk.set(isChecked)
            if(isChecked)
                binding.includeNotValid.spnDefType.setEnabled(true)
        }
        binding.includeNotValid.rbNk.setOnCheckedChangeListener { buttonView, isChecked ->
            viewModel.isNk.set(isChecked)
            viewModel.checkedChangeOutZoneNk(binding.includeNotValid.switchOutZoneNk.isChecked)
            if(isChecked)
                binding.includeNotValid.spnDefType.setEnabled(binding.includeNotValid.switchOutZoneNk.isChecked)
        }
        binding.switchFromPto.setOnCheckedChangeListener { buttonView, isChecked ->
            viewModel.checkedChangeFromPto(isChecked)
        }
        binding.includeNotValid.switchOutZoneNk.setOnCheckedChangeListener { buttonView, isChecked ->
            viewModel.checkedChangeOutZoneNk(isChecked)
            binding.includeNotValid.spnDefType.setEnabled(isChecked)
            /*if(isChecked)

            else
                binding.includeNotValid.switchOutZoneNk.setEnabled(false);*/
        }
        return binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        initRadioButtonFault()
        viewModel.getDetailLiveData(detailId, this).observe(this, Observer { detail ->
            detail?.let {
                binding.setVariable(BR.detail, it)
                binding.executePendingBindings()
                checkedRBFromPtoFault()
                //timeControl=DateUtils.getDateFromMills(detail.dateControl)
                if (isLoadedNsi) {
                    if (detailId > 0)
                        observeNsiData(it)
                    else
                        observeNsiData(null)
                }
            }
        })
        viewModel.eventLiveData.observe(this, Observer { event ->
            when (event.event) {
                Event.ACTION -> {
                    if(event.msg.equals(viewModel.ACTION_GO_TO_LIST_DETAIL))
                        goToBack()
                }
                Event.ERROR -> {
                    showToast(event.msg)
                }
                else -> {
                    print("")
                }
            }
        })
    }

    fun showToast(msg:String){
        Toast.makeText(context,msg,Toast.LENGTH_SHORT).show()
    }

    fun showDatePickerDialog(date: Date?) {
        viewModel.getDateDialog(this, date).show(fragmentManager!!, "datePicker")
    }

    override fun onDateComplete(time: Calendar) {
        viewModel.setDateControlToDetail(time)
    }

    private fun initRadioButtonFault(){

        binding.rbVrk1.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked) viewModel.setFault(true, 1)
        }
        binding.rbVrk2.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked) viewModel.setFault(true, 2)
        }
        binding.rbVrk3.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked) viewModel.setFault(true, 3)
        }
        binding.rbVrk4.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked) viewModel.setFault(true, 4)
        }
        binding.cbFault1.setOnClickListener {
            if((it as CheckBox).isChecked) {
                clearCheckBoxes()
                it.isChecked=true
                viewModel.setFault(false, 1)
            }
            else viewModel.setFault(false, 0)
        }
        binding.cbFault2.setOnClickListener {
            if((it as CheckBox).isChecked) {
                clearCheckBoxes()
                it.isChecked=true
                viewModel.setFault(false, 2)
            }
            else viewModel.setFault(false, 0)
        }
        binding.cbFault3.setOnClickListener {
            if((it as CheckBox).isChecked) {
                clearCheckBoxes()
                it.isChecked=true
                viewModel.setFault(false, 3)
            }
            else viewModel.setFault(false, 0)
        }
    }

    private fun clearCheckBoxes(){
        binding.cbFault1.isChecked=false
        binding.cbFault2.isChecked=false
        binding.cbFault3.isChecked=false
    }

    private fun checkedRBFromPtoFault(){
        val numbers: Array<Int?> = viewModel.getVrkFault()
        if(numbers.size==2){
            val rbId = "rb_vrk_" + numbers[0]
            val rb: RadioButton? = binding.root.findViewWithTag(rbId)
            rb?.isChecked = true
            val cbId = "cb_fault_" + numbers[1]
            val cb:CheckBox? = binding.root.findViewWithTag(cbId)
            cb?.isChecked = true
        }
    }

    private fun observeNsiData(detail: DetailNum?) {
        isLoadedNsi = false
        yearsCreate = DateUtils.getLastNYears(50)
        viewModel.setYearCreate(yearsCreate)
        setSpinnerYears(yearsCreate, detail?.yearCreate)
        //binding.tvDateControl.text=DateUtils.getSimpleDateStr(timeControl!!)
        viewModel.getControlResults(typeDetail).observe(this, Observer { results ->
            binding.rgControlResults.removeAllViewsInLayout()
            for (result in results) {
                val radioButton = RadioButton(context)
                radioButton.tag = ("rb_" + result.id)
                radioButton.text = result.name.capitalize()
                radioButton.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                val param = radioButton.layoutParams as LinearLayout.LayoutParams
                param.setMargins(8, 8, 8, 8)
                radioButton.layoutParams = param
                radioButton.setTextSize(
                    TypedValue.COMPLEX_UNIT_PX, context!!.resources.getDimension(
                        com.example.fmkinp.R.dimen.middlebig_text_size
                    )
                )
                radioButton.setOnCheckedChangeListener { buttonView, isChecked ->
                    viewModel.setResultControl(result, isChecked)

                    val tf = viewModel.isBrakCheck.get()
                            && !binding.includeNotValid.switchOutZoneNk.isChecked
                            && binding.includeNotValid.rbNk.isChecked
                    binding.includeNotValid.spnDefType.setEnabled(!tf)
                    /*if(viewModel.isRepairCheck.get())
                        binding.includeNotValid.spnDefType.setEnabled(true)
                    if(viewModel.isBrakCheck.get())
                        binding.includeNotValid.spnDefType.setEnabled(binding.includeNotValid.switchOutZoneNk.isChecked)*/
                   binding.includeNotValid.switchOutZoneNk.isChecked= Converter.convertToBoolean(viewModel.detailNum?.isNotVZoneNk!!)
                    //binding.includeNotValid.spnDefType.setEnabled(true)
                    //binding.includeNotValid.rbVisibleBeforeNk.isChecked=true
                    binding.includeNotValid.rbVisibleBeforeNk.isChecked=viewModel.isVisibleBeforeNk.get()
                    defectTypes.clear()
                    defectTypes.addAll(viewModel.getTypesDefect())
                    adapterDefectType?.notifyDataSetChanged()
                    //nothingAdapterDefectType?.updateAdapter(adapterDefectType)
                    //nothingAdapterDefectType.
                }
                binding.rgControlResults.addView(radioButton)
            }
            detail?.let {
                val rbId = "rb_" + it.resultControl
                val rb: RadioButton? = binding.root.findViewWithTag(rbId)
                rb?.isChecked = true
            }
        })
        viewModel.getFactorysCreate(typeDetail).observe(this, Observer {
            viewModel.setFactoryCreate(it)
            setSpinnerFactory(it, detail?.idFactory)
        })
        viewModel.getEntSpecialists().observe(this, Observer {
            viewModel.setEntSpecialist(it)
            setSpinnerFioSpec(it, detail?.fioSpec)
        })

        viewModel.getDefectTypes(typeDetail).observe(this, Observer {
            viewModel.defectTypesAll=it
            defectTypes = viewModel.getTypesDefect()
            viewModel.setTypesDefect()
            setSpinnerDefectType(/*defectTypes, */0,0, detail?.typeDef)
        })
        viewModel.getDefectZones(typeDetail).observe(this, Observer {
            viewModel.setZonesDefect(it)
            setSpinnerDefectZone(it, 0,0, detail?.zoneDef)
        })
        viewModel.getSteels().observe(this, Observer {
            viewModel.setSteel(it)
            setSpinnerSteel(it, detail?.steel)
        })
        viewModel.getMethodNkTypes(typeDetail).observe(this, Observer {
            viewModel.setMethodNkTypes(it)
            setSpinnerMethodNkType(it, detail?.methodType)
        })
        viewModel.getDefectDetectorTypes().observe(this, Observer {
            viewModel.setDefectDetectorTypes(it)
            setSpinnerDefectDetectorType(it,  detail?.defectDetector)
        })
    }

    private fun setSpinnerYears(years: List<Int>, defaultValue: Int?) {
        val adapter = ArrayAdapter<Int>(context, R.layout.my_spinner_item, years)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.spnYearCreate.prompt = context?.getString(R.string.tv_tittle_spn_years)/*"Выберите год"*/
        binding.spnYearCreate.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,
            /*"Выберите год"*/context?.getString(R.string.tv_tittle_spn_years),
            context
        ))
    }

    private fun setSpinnerFioSpec(specs: List<EntSpecialist>, defaultValue: String?) {
        val adapter = ArrayAdapter<EntSpecialist>(context, R.layout.my_spinner_item, specs)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.spnFioSpec.prompt = context?.getString(R.string.tv_tittle_spn_fio_spec)/*"Выберите специалиста"*/
        binding.spnFioSpec.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,
            /*"Выберите специалиста"*/context?.getString(R.string.tv_tittle_spn_fio_spec),
            context
        ))
    }

    private fun setSpinnerFactory(factorys: List<FactoryDetail>, defaultValue: Int?) {
        val adapter = ArrayAdapter<FactoryDetail>(context, R.layout.my_spinner_item, factorys)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.spnFactory.prompt = context?.getString(R.string.tv_tittle_spn_factory)/*"Выберите завод"*/
        binding.spnFactory.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,
            context?.getString(R.string.tv_tittle_spn_factory)/*"Выберите завод"*/,
            context
        ))
    }

    private fun setSpinnerDefectType(/*defectTypes: List<DefectType>,*/ brakRepair:Int, whenFind:Int, defaultValue: Int?) {
        adapterDefectType = ArrayAdapter<DefectType>(context, R.layout.my_spinner_item, defectTypes)
        adapterDefectType?.setDropDownViewResource(R.layout.my_spinner_item)
        binding.spnYearCreate.prompt = context?.getString(R.string.tv_tittle_spn_def_type)
        nothingAdapterDefectType = NothingSelectedSpinnerAdapter(
            adapterDefectType,
            R.layout.contact_spinner_row_nothing_selected,
            context?.getString(R.string.tv_tittle_spn_def_type),
            context
        )

        binding.includeNotValid.spnDefType.setAdapter(nothingAdapterDefectType)


        /*adapterDefectType = ArrayAdapter<DefectType>(context, R.layout.my_spinner_item, defectTypes)
        adapterDefectType?.setDropDownViewResource(R.layout.my_spinner_item)
        val spinner = binding.includeNotValid.spnDefType
        spinner.setAdapter(adapterDefectType)*/
    }

    private fun setSpinnerDefectZone(defectZones: List<DefectZone>, brakRepair:Int, whenFind:Int, defaultValue: Int?) {
        /*val adapter = ArrayAdapter<DefectZone>(context, R.layout.my_spinner_item, defectZones)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        val spinner = binding.includeNotValid.spnZone
        spinner.setAdapter(adapter)*/
        val adapter = ArrayAdapter<DefectZone>(context, R.layout.my_spinner_item, defectZones)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnZone.prompt = context?.getString(R.string.tv_tittle_spn_zone)/*"Выберите зону выявления"*/
        binding.includeNotValid.spnZone.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,
            context?.getString(R.string.tv_tittle_spn_zone)/*"Выберите зону выявления"*/,
            context
        ))
    }

    private fun setSpinnerSteel(steels: List<Steel>, defaultValue: String?) {
        val adapter = ArrayAdapter<Steel>(context, R.layout.my_spinner_item, steels)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnSteelType.prompt = context?.getString(R.string.tv_tittle_spn_steel)/*"Выберите марку стали"*/
        binding.includeNotValid.spnSteelType.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,  // R.layout.contact_spinner_nothing_selected_dropdown, // Optional
            context?.getString(R.string.tv_tittle_spn_steel)/*"Выберите марку стали"*/,
            context
        ))
        /*val adapter = ArrayAdapter<Steel>(context, R.layout.my_spinner_item, steels)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnSteelType.setAdapter(adapter);*/
    }

    private fun setSpinnerMethodNkType(methodNkTypes: List<MethodNkType>, defaultValue: String?) {
        val adapter = ArrayAdapter<MethodNkType>(context, R.layout.my_spinner_item, methodNkTypes)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnMetodType.prompt = context?.getString(R.string.tv_tittle_spn_method_type)/*"Выберите метод"*/
        binding.includeNotValid.spnMetodType.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,
            context?.getString(R.string.tv_tittle_spn_method_type)/*"Выберите метод"*/,
            context
        ))/*
        val adapter = ArrayAdapter<MethodNkType>(context, R.layout.my_spinner_item, methodNkTypes)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnMetodType.setAdapter(adapter)*/
    }

    private fun setSpinnerDefectDetectorType(defectDetectorTypes: List<DefectDetectorType>, defaultValue: String?) {
        val adapter = ArrayAdapter<DefectDetectorType>(context, R.layout.my_spinner_item, defectDetectorTypes)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnDefektoskopType.prompt = context?.getString(R.string.tv_tittle_spn_detector_type)/*"Выберите тип дефектоскопа"*/
        binding.includeNotValid.spnDefektoskopType.setAdapter( NothingSelectedSpinnerAdapter(
            adapter,
            R.layout.contact_spinner_row_nothing_selected,
            context?.getString(R.string.tv_tittle_spn_detector_type) /*"Выберите тип дефектоскопа"*/,
            context
        ))/*
        val adapter = ArrayAdapter<DefectDetectorType>(context, R.layout.my_spinner_item, defectDetectorTypes)
        adapter.setDropDownViewResource(R.layout.my_spinner_item)
        binding.includeNotValid.spnDefektoskopType.setAdapter(adapter)*/
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.action_menu_edit, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    fun Fragment.hideKeyboard() {
        view?.let { activity?.hideKeyboard(it) }
    }

    fun Activity.hideKeyboard() {
        hideKeyboard(currentFocus ?: View(this))
    }

    fun Context.hideKeyboard(view: View) {
        val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_save -> {
            hideKeyboard()
            viewModel.saveDetail()
            //showToast("defectTypesValue "+viewModel.defectTypeValue)
            
            /*isTablet -> {
                val navHostFragment = parentFragment?.fragmentManager?.findFragmentById(R.id.detail_nav_container) as NavHostFragment
                val bundleToTransfer = Bundle()
                bundleToTransfer.putInt("key_id_detail", detailId)
                bundleToTransfer.putInt("key_type_detail", typeDetail)
                navHostFragment.navController.navigate(R.id.detailCastEditFragment, bundleToTransfer)
            }
            else -> {
                val action = DetailCastViewFragmentDirections.actionDetailCastViewFragmentToDetailCastEditFragment(detailId, typeDetail)
                view?.let { Navigation.findNavController(it).navigate(action) }!!
            }*/
            //}
            true
        }
        else -> {
            super.onOptionsItemSelected(item)
        }
    }

    fun goToBack(){
        if(isTablet){
            val navHostFragment = parentFragment?.fragmentManager?.findFragmentById(R.id.detail_nav_container) as NavHostFragment
            navHostFragment.navController.navigate(R.id.detailDefaultFragment)
        }
        else {
            val action = DetailCastEditFragmentDirections.actionDetailCastEditFragmentToControlListFragment()
            view?.let { Navigation.findNavController(it).navigateUp()}!!
        }
    }
}
